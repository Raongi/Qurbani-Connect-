// Login function
async function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        const data = await apiRequest('/auth/login', {
            method: 'POST',
            body: { email, password }
        });
        
        // Save token and user
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    } catch (error) {
        alert('Login failed: ' + error.message);
    }
}

// Add event listener
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    login();
});