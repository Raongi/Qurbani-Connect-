// Group Orders JavaScript file

document.addEventListener('DOMContentLoaded', function() {
    // Initialize group orders functionality
    
    // Set minimum date to today for date inputs
    const dateInput = document.getElementById('pickupDate');
    if (dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.min = today;
        
        // Set default value to tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        dateInput.value = tomorrow.toISOString().split('T')[0];
    }
    
    // Create group order form submission
    const createGroupOrderForm = document.getElementById('createGroupOrderForm');
    if (createGroupOrderForm) {
        createGroupOrderForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const market = document.getElementById('market').value;
            const pickupDate = document.getElementById('pickupDate').value;
            const pickupTime = document.getElementById('pickupTime').value;
            const maxMembers = document.getElementById('maxMembers').value;
            const dropOffLocation = document.getElementById('dropOffLocation').value;
            const notes = document.getElementById('notes').value;
            
            // In a real app, this would submit the data to the server
            // For now, we'll just show a success message
            const alertDiv = document.createElement('div');
            alertDiv.className = 'alert alert-success mt-3';
            alertDiv.textContent = 'Group order created successfully! You will be notified when other members join.';
            createGroupOrderForm.appendChild(alertDiv);
            
            // Reset form
            createGroupOrderForm.reset();
            
            // Remove alert after 5 seconds
            setTimeout(() => {
                alertDiv.remove();
            }, 5000);
        });
    }
    
    // Join group button click handler
    const joinGroupButtons = document.querySelectorAll('.btn-primary');
    joinGroupButtons.forEach(button => {
        if (button.textContent === 'Join Group') {
            button.addEventListener('click', function() {
                const card = this.closest('.card-body');
                const groupName = card.querySelector('.card-title').textContent;
                
                // In a real app, this would add the user to the group
                // For now, we'll just show a confirmation message
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-success mt-3';
                alertDiv.textContent = `You have successfully joined the "${groupName}". You will receive updates about this group order.`;
                
                // Insert alert after the card
                card.parentElement.after(alertDiv);
                
                // Disable the button and change its text
                this.textContent = 'Joined';
                this.disabled = true;
                this.className = 'btn btn-success';
                
                // Update the members count
                const membersText = card.querySelector('.fa-users').parentElement.textContent;
                const currentMembers = parseInt(membersText.match(/\d+/)[0]);
                const maxMembers = parseInt(membersText.match(/\/\d+/)[0].substring(1));
                const newMembersText = membersText.replace(`${currentMembers}/${maxMembers}`, `${currentMembers + 1}/${maxMembers}`);
                card.querySelector('.fa-users').parentElement.textContent = newMembersText;
                
                // Update progress bar
                const progressBar = card.querySelector('.progress-bar');
                const newPercentage = ((currentMembers + 1) / maxMembers) * 100;
                progressBar.style.width = `${newPercentage}%`;
                progressBar.setAttribute('aria-valuenow', newPercentage);
                progressBar.textContent = `${Math.round(newPercentage)}%`;
                
                // Change badge if group is almost full
                if (newPercentage >= 80 && newPercentage < 100) {
                    const badge = card.querySelector('.badge');
                    badge.textContent = 'Filling Fast';
                    badge.className = 'badge bg-warning';
                } else if (newPercentage >= 100) {
                    const badge = card.querySelector('.badge');
                    badge.textContent = 'Full';
                    badge.className = 'badge bg-danger';
                }
                
                // Remove alert after 5 seconds
                setTimeout(() => {
                    alertDiv.remove();
                }, 5000);
            });
        }
    });
    
    // View button click handler in My Group Orders table
    const viewButtons = document.querySelectorAll('.btn-edit');
    viewButtons.forEach(button => {
        if (button.textContent === 'View') {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const orderId = row.querySelector('td:first-child').textContent;
                const market = row.querySelector('td:nth-child(2)').textContent;
                const members = row.querySelector('td:nth-child(4)').textContent;
                
                // In a real app, this would show detailed information about the group order
                alert(`Group Order Details:\n\nOrder ID: ${orderId}\nMarket: ${market}\nMembers: ${members}\n\nThis would show a detailed view with all member information and contact details.`);
            });
        }
    });
    
    // Leave button click handler in My Group Orders table
    const leaveButtons = document.querySelectorAll('.btn-danger');
    leaveButtons.forEach(button => {
        if (button.textContent === 'Leave') {
            button.addEventListener('click', function() {
                if (confirm('Are you sure you want to leave this group order?')) {
                    const row = this.closest('tr');
                    const orderId = row.querySelector('td:first-child').textContent;
                    
                    // In a real app, this would remove the user from the group
                    alert(`You have left the group order ${orderId}.`);
                    
                    // Update the status to "Left"
                    const statusCell = row.querySelector('td:nth-child(5)');
                    statusCell.innerHTML = '<span class="badge badge-rejected">Left</span>';
                    
                    // Disable the Leave button
                    this.disabled = true;
                    this.textContent = 'Left';
                }
            });
        }
    });
    
    // Rate button click handler in My Group Orders table
    const rateButtons = document.querySelectorAll('.btn-success');
    rateButtons.forEach(button => {
        if (button.textContent === 'Rate') {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const orderId = row.querySelector('td:first-child').textContent;
                
                // In a real app, this would open a rating modal
                const rating = prompt(`Please rate your experience with group order ${orderId} (1-5):`);
                
                if (rating && !isNaN(rating) && rating >= 1 && rating <= 5) {
                    alert(`Thank you for rating ${orderId} with ${rating} stars!`);
                    
                    // Disable the Rate button
                    this.disabled = true;
                    this.textContent = 'Rated';
                } else if (rating !== null) {
                    alert('Please enter a valid rating between 1 and 5.');
                }
            });
        }
    });
    
    // Add hover effect to group order cards
    const groupOrderCards = document.querySelectorAll('.card');
    groupOrderCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 8px 30px rgba(139, 0, 0, 0.2)';
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '';
            this.style.transform = '';
        });
    });
    
    // Simulate real-time updates to group orders
    setInterval(function() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const currentValue = parseInt(bar.getAttribute('aria-valuenow'));
            const change = Math.random() > 0.7 ? 10 : 0; // 30% chance of increase
            
            if (change > 0 && currentValue < 100) {
                const newValue = Math.min(100, currentValue + change);
                bar.style.width = `${newValue}%`;
                bar.setAttribute('aria-valuenow', newValue);
                bar.textContent = `${newValue}%`;
                
                // Update badge if needed
                const card = bar.closest('.card');
                const badge = card.querySelector('.badge');
                
                if (newValue >= 80 && newValue < 100 && badge.textContent === 'Open') {
                    badge.textContent = 'Filling Fast';
                    badge.className = 'badge bg-warning';
                } else if (newValue >= 100) {
                    badge.textContent = 'Full';
                    badge.className = 'badge bg-danger';
                    
                    // Disable the Join button
                    const joinButton = card.querySelector('.btn-primary');
                    if (joinButton && joinButton.textContent === 'Join Group') {
                        joinButton.textContent = 'Group Full';
                        joinButton.disabled = true;
                        joinButton.className = 'btn btn-secondary';
                    }
                }
            }
        });
    }, 30000); // Check every 30 seconds
});