// Load dashboard data
async function loadDashboard() {
    try {
        const stats = await apiRequest('/bookings/stats');
        
        document.getElementById('activeBookingsCount').textContent = stats.activeBookings || 0;
        document.getElementById('groupOrdersCount').textContent = stats.groupOrders || 0;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}
const API_BASE_URL = 'https://localhost:5001/api';

async function registerUser(userData) {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
    });
    
    const result = await response.json();
    alert(result.message);
}

// Load when page opens
document.addEventListener('DOMContentLoaded', loadDashboard);