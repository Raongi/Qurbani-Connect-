// Load markets
async function loadMarkets() {
    try {
        const markets = await apiRequest('/markets');
        
        const marketsList = document.getElementById('marketsList');
        marketsList.innerHTML = '';
        
        if (markets.length === 0) {
            marketsList.innerHTML = '<div class="col-12 text-center py-5">No markets available</div>';
            return;
        }
        
        markets.forEach(market => {
            const marketCard = `
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5>${market.name}</h5>
                            <p>${market.location}</p>
                            <button class="btn btn-primary">View Animals</button>
                        </div>
                    </div>
                </div>
            `;
            marketsList.innerHTML += marketCard;
        });
    } catch (error) {
        console.error('Error loading markets:', error);
        document.getElementById('marketsList').innerHTML = '<div class="col-12 text-center py-5">Failed to load markets</div>';
    }
}

// Load when page opens
document.addEventListener('DOMContentLoaded', loadMarkets);