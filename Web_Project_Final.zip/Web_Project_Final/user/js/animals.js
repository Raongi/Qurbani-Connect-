// Animals JavaScript file

document.addEventListener('DOMContentLoaded', function() {
    // Initialize animals functionality
    
    // Filter functionality
    const filterButton = document.querySelector('.btn-primary');
    if (filterButton && filterButton.textContent === 'Filter') {
        filterButton.addEventListener('click', function() {
            // In a real app, this would filter the animals based on selected criteria
            alert('Filtering animals based on your criteria...');
        });
    }
    
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const animalCards = document.querySelectorAll('.col-md-4');
            
            animalCards.forEach(card => {
                const animalName = card.querySelector('.card-title').textContent.toLowerCase();
                const animalDetails = card.querySelector('.card-text').textContent.toLowerCase();
                
                if (animalName.includes(searchTerm) || animalDetails.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // Book Now button click handler
    const bookNowButtons = document.querySelectorAll('.btn-primary');
    bookNowButtons.forEach(button => {
        if (button.textContent === 'Book Now') {
            button.addEventListener('click', function() {
                // In a real app, this would add the animal to the booking cart
                const animalName = this.closest('.card-body').querySelector('.card-title').textContent;
                const animalPrice = this.closest('.card-body').querySelector('.text-danger').textContent;
                
                // Store selected animal in localStorage for booking page
                localStorage.setItem('selectedAnimal', JSON.stringify({
                    name: animalName,
                    price: animalPrice
                }));
                
                // Redirect to booking page
                window.location.href = 'booking.html';
            });
        }
    });
    
    // Add hover effect to animal cards
    const animalCards = document.querySelectorAll('.card');
    animalCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 8px 30px rgba(139, 0, 0, 0.2)';
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '';
            this.style.transform = '';
        });
    });
    
    // Simulate real-time stock updates
    setInterval(function() {
        const stockBadges = document.querySelectorAll('.badge');
        stockBadges.forEach(badge => {
            if (badge.textContent === 'Limited Stock' && Math.random() > 0.7) {
                badge.textContent = 'Sold Out';
                badge.className = 'badge bg-danger';
                
                // Disable the Book Now button
                const bookButton = badge.closest('.card-body').querySelector('.btn-primary');
                if (bookButton) {
                    bookButton.textContent = 'Not Available';
                    bookButton.disabled = true;
                    bookButton.className = 'btn btn-secondary';
                }
            }
        });
    }, 30000); // Check every 30 seconds
    
    // Price comparison table highlighting
    const tableRows = document.querySelectorAll('.data-table tbody tr');
    tableRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        let minPrice = Infinity;
        let minPriceIndex = -1;
        
        // Find the minimum price (excluding the first and last columns)
        for (let i = 1; i < cells.length - 1; i++) {
            const priceText = cells[i].textContent.replace('Rs. ', '').replace(',', '');
            const price = parseInt(priceText);
            
            if (price < minPrice) {
                minPrice = price;
                minPriceIndex = i;
            }
        }
        
        // Highlight the minimum price
        if (minPriceIndex !== -1) {
            cells[minPriceIndex].style.fontWeight = 'bold';
            cells[minPriceIndex].style.color = '#8B0000';
        }
    });
});