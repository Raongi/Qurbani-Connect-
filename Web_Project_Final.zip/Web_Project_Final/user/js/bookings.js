// Bookings JavaScript file

document.addEventListener('DOMContentLoaded', function() {
    // Initialize bookings functionality
    
    // View button click handler
    const viewButtons = document.querySelectorAll('.btn-edit');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const bookingId = row.querySelector('td:first-child').textContent;
            const serviceType = row.querySelector('td:nth-child(2)').textContent;
            const date = row.querySelector('td:nth-child(3)').textContent;
            const details = row.querySelector('td:nth-child(4)').innerHTML;
            const amount = row.querySelector('td:nth-child(5)').textContent;
            const status = row.querySelector('td:nth-child(6)').innerHTML;
            
            // Update modal content
            const modalTitle = document.getElementById('bookingDetailsModalLabel');
            const modalBody = document.querySelector('#bookingDetailsModal .modal-body');
            
            if (modalTitle && modalBody) {
                modalTitle.textContent = `Booking Details - ${bookingId}`;
                
                modalBody.innerHTML = `
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Booking Information</h6>
                            <p><strong>Booking ID:</strong> ${bookingId}</p>
                            <p><strong>Booking Date:</strong> Nov 5, 2025</p>
                            <p><strong>Service Type:</strong> ${serviceType}</p>
                            <p><strong>Status:</strong> ${status}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Service Details</h6>
                            <p>${details.replace(/<br>/g, '<br>')}</p>
                            <p><strong>Pickup Date:</strong> ${date}</p>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h6>Payment Information</h6>
                            <p><strong>Total Amount:</strong> ${amount}</p>
                            <p><strong>Payment Method:</strong> Cash on Delivery</p>
                            <p><strong>Payment Status:</strong> <span class="badge badge-pending">Pending</span></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Contact Information</h6>
                            <p><strong>Contact:</strong> +92 300 1234567</p>
                            <p><strong>Address:</strong> Islamabad</p>
                            <p><strong>Special Instructions:</strong> None</p>
                        </div>
                    </div>
                `;
                
                // Show the modal
                const modal = new bootstrap.Modal(document.getElementById('bookingDetailsModal'));
                modal.show();
            }
        });
    });
    
    // Cancel button click handler
    const cancelButtons = document.querySelectorAll('.btn-danger');
    cancelButtons.forEach(button => {
        if (button.textContent === 'Cancel') {
            button.addEventListener('click', function() {
                if (confirm('Are you sure you want to cancel this booking?')) {
                    const row = this.closest('tr');
                    const bookingId = row.querySelector('td:first-child').textContent;
                    
                    // In a real app, this would send a request to the server
                    alert(`Booking ${bookingId} has been cancelled.`);
                    
                    // Update the status
                    const statusCell = row.querySelector('td:nth-child(6)');
                    statusCell.innerHTML = '<span class="badge badge-rejected">Cancelled</span>';
                    
                    // Disable the Cancel button
                    this.disabled = true;
                    this.textContent = 'Cancelled';
                }
            });
        }
    });
    
    // Leave button click handler (for group orders)
    const leaveButtons = document.querySelectorAll('.btn-danger');
    leaveButtons.forEach(button => {
        if (button.textContent === 'Leave') {
            button.addEventListener('click', function() {
                if (confirm('Are you sure you want to leave this group order?')) {
                    const row = this.closest('tr');
                    const orderId = row.querySelector('td:first-child').textContent;
                    
                    // In a real app, this would send a request to the server
                    alert(`You have left the group order ${orderId}.`);
                    
                    // Update the status
                    const statusCell = row.querySelector('td:nth-child(6)');
                    statusCell.innerHTML = '<span class="badge badge-rejected">Left</span>';
                    
                    // Disable the Leave button
                    this.disabled = true;
                    this.textContent = 'Left';
                }
            });
        }
    });
    
    // Rate button click handler
    const rateButtons = document.querySelectorAll('.btn-success');
    rateButtons.forEach(button => {
        if (button.textContent === 'Rate') {
            button.addEventListener('click', function() {
                const row = this.closest('tr');
                const bookingId = row.querySelector('td:first-child').textContent;
                const serviceType = row.querySelector('td:nth-child(2)').textContent;
                
                // In a real app, this would open a rating modal
                const rating = prompt(`Please rate your experience with ${serviceType} (${bookingId}) (1-5):`);
                
                if (rating && !isNaN(rating) && rating >= 1 && rating <= 5) {
                    alert(`Thank you for rating ${bookingId} with ${rating} stars!`);
                    
                    // Disable the Rate button
                    this.disabled = true;
                    this.textContent = 'Rated';
                } else if (rating !== null) {
                    alert('Please enter a valid rating between 1 and 5.');
                }
            });
        }
    });
    
    // Print Receipt button click handler
    const printButton = document.querySelector('#bookingDetailsModal .btn-primary');
    if (printButton && printButton.textContent === 'Print Receipt') {
        printButton.addEventListener('click', function() {
            // In a real app, this would generate a printable receipt
            window.print();
        });
    }
    
    // Simulate real-time booking updates
    setInterval(function() {
        const statusBadges = document.querySelectorAll('.badge-pending');
        statusBadges.forEach(badge => {
            if (Math.random() > 0.7) { // 30% chance of status change
                badge.className = 'badge badge-approved';
                badge.textContent = 'Confirmed';
                
                // Show notification
                const row = badge.closest('tr');
                const bookingId = row.querySelector('td:first-child').textContent;
                
                // In a real app, this would show a proper notification
                console.log(`Booking ${bookingId} has been confirmed!`);
            }
        });
    }, 60000); // Check every minute
});