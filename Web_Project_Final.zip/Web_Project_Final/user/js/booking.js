// Booking JavaScript file

document.addEventListener('DOMContentLoaded', function() {
    // Initialize booking functionality
    
    // Set minimum date to today for date inputs
    const dateInputs = document.querySelectorAll('input[type="date"]');
    const today = new Date().toISOString().split('T')[0];
    dateInputs.forEach(input => {
        input.min = today;
        
        // Set default value to tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        input.value = tomorrow.toISOString().split('T')[0];
    });
    
    // Animal selection handling
    const animalRadios = document.querySelectorAll('input[name="animal"]');
    animalRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                const card = this.closest('.card-body');
                const price = card.querySelector('.text-danger').textContent;
                
                // Update total price
                const totalElement = document.querySelector('#animalBookingForm h4');
                if (totalElement) {
                    totalElement.textContent = `Total: ${price}`;
                }
            }
        });
    });
    
    // Butcher selection handling
    const butcherRadios = document.querySelectorAll('input[name="butcher"]');
    butcherRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                const card = this.closest('.card-body');
                const pricePerAnimal = card.querySelector('.text-danger').textContent;
                const animalCount = document.getElementById('animalCount').value;
                
                // Calculate total price
                const priceValue = parseInt(pricePerAnimal.replace('Rs. ', '').replace(' per animal', ''));
                const totalPrice = priceValue * animalCount;
                
                // Update total price
                const totalElement = document.querySelector('#butcherBookingForm h4');
                if (totalElement) {
                    totalElement.textContent = `Total: Rs. ${totalPrice}`;
                }
            }
        });
    });
    
    // Animal count change handler
    const animalCountInput = document.getElementById('animalCount');
    if (animalCountInput) {
        animalCountInput.addEventListener('input', function() {
            const selectedButcher = document.querySelector('input[name="butcher"]:checked');
            if (selectedButcher) {
                const card = selectedButcher.closest('.card-body');
                const pricePerAnimal = card.querySelector('.text-danger').textContent;
                
                // Calculate total price
                const priceValue = parseInt(pricePerAnimal.replace('Rs. ', '').replace(' per animal', ''));
                const totalPrice = priceValue * this.value;
                
                // Update total price
                const totalElement = document.querySelector('#butcherBookingForm h4');
                if (totalElement) {
                    totalElement.textContent = `Total: Rs. ${totalPrice}`;
                }
            }
        });
    }
    
    // Combined booking handling
    const combinedAnimalRadios = document.querySelectorAll('input[name="combinedAnimal"]');
    const combinedButcherRadios = document.querySelectorAll('input[name="combinedButcher"]');
    
    function updateCombinedTotal() {
        const selectedAnimal = document.querySelector('input[name="combinedAnimal"]:checked');
        const selectedButcher = document.querySelector('input[name="combinedButcher"]:checked');
        
        if (selectedAnimal && selectedButcher) {
            const animalCard = selectedAnimal.closest('.card-body');
            const butcherCard = selectedButcher.closest('.card-body');
            
            const animalPrice = parseInt(animalCard.querySelector('.text-danger').textContent.replace('Rs. ', '').replace(',', ''));
            const butcherPrice = parseInt(butcherCard.querySelector('.text-danger').textContent.replace('Rs. ', '').replace(' per animal', ''));
            
            const totalPrice = animalPrice + butcherPrice;
            
            // Update total price
            const totalElement = document.querySelector('#combinedBookingForm h4');
            const smallElement = totalElement.nextElementSibling;
            
            if (totalElement) {
                totalElement.textContent = `Total: Rs. ${totalPrice.toLocaleString()}`;
            }
            
            if (smallElement) {
                smallElement.textContent = `Animal: Rs. ${animalPrice.toLocaleString()} + Butcher: Rs. ${butcherPrice}`;
            }
        }
    }
    
    combinedAnimalRadios.forEach(radio => {
        radio.addEventListener('change', updateCombinedTotal);
    });
    
    combinedButcherRadios.forEach(radio => {
        radio.addEventListener('change', updateCombinedTotal);
    });
    
    // Form submission handlers
    const animalBookingForm = document.getElementById('animalBookingForm');
    if (animalBookingForm) {
        animalBookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real app, this would submit the booking to the server
            alert('Animal booking submitted! You will be redirected to the payment page.');
            
            // Redirect to payment page (in a real app)
            // window.location.href = 'payment.html';
        });
    }
    
    const butcherBookingForm = document.getElementById('butcherBookingForm');
    if (butcherBookingForm) {
        butcherBookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real app, this would submit the booking to the server
            alert('Butcher booking submitted! You will be redirected to the payment page.');
            
            // Redirect to payment page (in a real app)
            // window.location.href = 'payment.html';
        });
    }
    
    const combinedBookingForm = document.getElementById('combinedBookingForm');
    if (combinedBookingForm) {
        combinedBookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // In a real app, this would submit the booking to the server
            alert('Combined booking submitted! You will be redirected to the payment page.');
            
            // Redirect to payment page (in a real app)
            // window.location.href = 'payment.html';
        });
    }
    
    // Check for pre-selected items from localStorage
    const selectedAnimal = localStorage.getItem('selectedAnimal');
    const selectedButcher = localStorage.getItem('selectedButcher');
    
    if (selectedAnimal) {
        const animal = JSON.parse(selectedAnimal);
        // In a real app, this would pre-select the animal and switch to the appropriate tab
        console.log('Pre-selected animal:', animal);
    }
    
    if (selectedButcher) {
        const butcher = JSON.parse(selectedButcher);
        // In a real app, this would pre-select the butcher and switch to the appropriate tab
        console.log('Pre-selected butcher:', butcher);
    }
});