// Butchers JavaScript file

document.addEventListener('DOMContentLoaded', function() {
    // Initialize butchers functionality
    
    // Filter functionality
    const filterButton = document.querySelector('.btn-primary');
    if (filterButton && filterButton.textContent === 'Filter') {
        filterButton.addEventListener('click', function() {
            // In a real app, this would filter the butchers based on selected criteria
            alert('Filtering butchers based on your criteria...');
        });
    }
    
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const butcherCards = document.querySelectorAll('.col-md-6');
            
            butcherCards.forEach(card => {
                const butcherName = card.querySelector('.card-title').textContent.toLowerCase();
                const butcherDetails = card.querySelector('.card-text').textContent.toLowerCase();
                
                if (butcherName.includes(searchTerm) || butcherDetails.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }
    
    // Book Now button click handler
    const bookNowButtons = document.querySelectorAll('.btn-success');
    bookNowButtons.forEach(button => {
        if (button.textContent === 'Book Now') {
            button.addEventListener('click', function() {
                // In a real app, this would add the butcher to the booking cart
                const butcherName = this.closest('.card-body').querySelector('.card-title').textContent;
                const butcherPrice = this.closest('.card-body').querySelector('.text-danger').textContent;
                
                // Store selected butcher in localStorage for booking page
                localStorage.setItem('selectedButcher', JSON.stringify({
                    name: butcherName,
                    price: butcherPrice
                }));
                
                // Redirect to booking page
                window.location.href = 'booking.html';
            });
        }
    });
    
    // View Calendar button click handler
    const viewCalendarButtons = document.querySelectorAll('.btn-primary');
    viewCalendarButtons.forEach(button => {
        if (button.textContent === 'View Calendar') {
            button.addEventListener('click', function() {
                // Scroll to calendar view
                const calendarView = document.querySelector('.card-body .table-responsive');
                if (calendarView) {
                    calendarView.scrollIntoView({ behavior: 'smooth' });
                    
                    // Highlight the corresponding row in the calendar
                    const butcherName = this.closest('.card-body').querySelector('.card-title').textContent;
                    const tableRows = document.querySelectorAll('.table tbody tr');
                    
                    tableRows.forEach(row => {
                        const firstCell = row.querySelector('td:first-child');
                        if (firstCell && firstCell.textContent === butcherName) {
                            row.style.backgroundColor = 'rgba(139, 0, 0, 0.1)';
                            
                            // Remove highlight after 3 seconds
                            setTimeout(() => {
                                row.style.backgroundColor = '';
                            }, 3000);
                        }
                    });
                }
            });
        }
    });
    
    // Add hover effect to butcher cards
    const butcherCards = document.querySelectorAll('.card');
    butcherCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 8px 30px rgba(139, 0, 0, 0.2)';
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '';
            this.style.transform = '';
        });
    });
    
    // Calendar cell click handler
    const calendarCells = document.querySelectorAll('.table tbody td:not(:first-child)');
    calendarCells.forEach(cell => {
        cell.addEventListener('click', function() {
            const row = this.closest('tr');
            const butcherName = row.querySelector('td:first-child').textContent;
            const date = row.previousElementSibling.querySelectorAll('th')[this.cellIndex - 1].textContent;
            
            // In a real app, this would open a booking modal
            alert(`Booking ${butcherName} for ${date}`);
        });
    });
    
    // Simulate real-time availability updates
    setInterval(function() {
        const availabilityCells = document.querySelectorAll('.table tbody td:not(:first-child)');
        availabilityCells.forEach(cell => {
            if (Math.random() > 0.9) { // 10% chance of status change
                if (cell.classList.contains('bg-success')) {
                    cell.className = 'text-center bg-warning text-dark';
                    cell.textContent = 'Busy';
                } else if (cell.classList.contains('bg-warning')) {
                    cell.className = 'text-center bg-success text-white';
                    cell.textContent = 'Available';
                }
            }
        });
    }, 60000); // Check every minute
});