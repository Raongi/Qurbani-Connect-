using CattleMarketAPI.Models;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CattleMarketAPI.Services
{
    public class OrderService
    {
        private readonly IMongoCollection<Order> _orders;

        public OrderService(IMongoClient client)
        {
            var db = client.GetDatabase("cattle_market");
            _orders = db.GetCollection<Order>("OrderBookings");
        }

        public async Task<List<Order>> GetAllAsync() =>
            await _orders.Find(_ => true).ToListAsync();

        public async Task<Order> GetByIdAsync(string id) =>
            await _orders.Find(o => o.Id == id).FirstOrDefaultAsync();

        public async Task CreateAsync(Order order) =>
            await _orders.InsertOneAsync(order);

        public async Task UpdateAsync(string id, Order order) =>
            await _orders.ReplaceOneAsync(o => o.Id == id, order);
    }
}
