using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Services
{
    public class TransporterService
    {
        private readonly IMongoCollection<Transporter> _transporters;

        public TransporterService(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market");
            _transporters = database.GetCollection<Transporter>("Transporters"); // Your collection
        }

        public List<Transporter> GetAllTransporters()
        {
            return _transporters.Find(_ => true).ToList();
        }
    }
}
