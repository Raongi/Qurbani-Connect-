using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Configuration;

namespace CattleMarketAPI.Services
{
    public class SellerService
    {
        private readonly IMongoCollection<Seller> _sellers;
        private readonly IConfiguration _configuration;

        public SellerService(IMongoClient mongoClient, IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            var database = mongoClient.GetDatabase("cattle_market");
            _sellers = database.GetCollection<Seller>("Seller");
        }

        public async Task<List<Seller>> GetAllAsync() =>
            await _sellers.Find(s => true).ToListAsync();

        public async Task<Seller> GetByIdAsync(string id)
        {
            return await _sellers.Find(s => s.Id == id).FirstOrDefaultAsync();
        }

        public async Task<Seller> GetByEmailAsync(string email)
        {
            return await _sellers.Find(s => s.Email == email).FirstOrDefaultAsync();
        }

        public async Task CreateAsync(Seller seller)
        {
            await _sellers.InsertOneAsync(seller);
        }

        public string GenerateJwtToken(Seller seller)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, seller.FarmerName),
                new Claim(ClaimTypes.Email, seller.Email),
                new Claim(ClaimTypes.NameIdentifier, seller.Id)
            };

            var secretKey = _configuration["JwtSettings:SecretKey"] ?? "YourNewStrongSecretKeyHere1234567890";
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "yourapp.com",
                audience: "yourapp.com",
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

