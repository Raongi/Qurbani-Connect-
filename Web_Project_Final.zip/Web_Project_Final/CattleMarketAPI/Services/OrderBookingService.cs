using CattleMarketAPI.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CattleMarketAPI.Services
{
    public class OrderBookingService
    {
        private readonly IMongoCollection<OrderBooking> _orderBookings;

        public OrderBookingService(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market");
            _orderBookings = database.GetCollection<OrderBooking>("OrderBookings");
        }

        // Get all order bookings
        public List<OrderBooking> GetAllOrderBookings()
        {
            return _orderBookings.Find(_ => true).ToList();
        }

        // Get order booking by ID
        public OrderBooking GetOrderBookingById(string id)
        {
            return _orderBookings.Find(order => order.Id == id).FirstOrDefault();
        }

        // Create new order booking
        public OrderBooking CreateOrderBooking(OrderBooking orderBooking)
        {
            // ✅ CRITICAL FIX: MongoDB will auto-generate Id
            orderBooking.Id = null;

            // Ensure OrderDate is set
            if (orderBooking.OrderDate == default)
            {
                orderBooking.OrderDate = DateTime.Now;
            }

            // Calculate total price if not set
            if (orderBooking.TotalPrice == 0 && orderBooking.PricePerUnit > 0)
            {
                orderBooking.TotalPrice = orderBooking.PricePerUnit * orderBooking.Quantity;
            }

            // Set default status if not provided
            if (string.IsNullOrEmpty(orderBooking.Status))
            {
                orderBooking.Status = "Pending";
            }

            _orderBookings.InsertOne(orderBooking);
            return orderBooking;
        }

        // Update order booking
        public bool UpdateOrderBooking(string id, OrderBooking orderBooking)
        {
            orderBooking.Id = id; // Ensure ID matches
            var result = _orderBookings.ReplaceOne(
                order => order.Id == id, 
                orderBooking
            );
            return result.ModifiedCount > 0;
        }

        // Update order status
        public bool UpdateOrderStatus(string id, string status)
        {
            var update = Builders<OrderBooking>.Update.Set(o => o.Status, status);
            var result = _orderBookings.UpdateOne(
                order => order.Id == id, 
                update
            );
            return result.ModifiedCount > 0;
        }

        // Delete order booking
        public bool DeleteOrderBooking(string id)
        {
            var result = _orderBookings.DeleteOne(order => order.Id == id);
            return result.DeletedCount > 0;
        }

        // Get orders by customer email
        public List<OrderBooking> GetOrderBookingsByCustomer(string email)
        {
            return _orderBookings
                .Find(order => order.CustomerEmail == email)
                .ToList();
        }

        // Get orders by status
        public List<OrderBooking> GetOrderBookingsByStatus(string status)
        {
            return _orderBookings
                .Find(order => order.Status == status)
                .ToList();
        }
    }
}