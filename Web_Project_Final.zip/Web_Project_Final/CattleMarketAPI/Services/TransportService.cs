using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

public class TransportService
{
    private readonly IMongoCollection<Transport> _transporters;

    public TransportService(IMongoClient mongoClient)
    {
        var database = mongoClient.GetDatabase("cattle_market");
        _transporters = database.GetCollection<Transport>("transporter");
    }

    public async Task<List<Transport>> GetAllAsync() =>
        await _transporters.Find(_ => true).ToListAsync();

    public async Task<Transport> GetByEmailAsync(string email) =>
        await _transporters.Find(t => t.Email == email).FirstOrDefaultAsync();

    public async Task CreateAsync(Transport transporter) =>
        await _transporters.InsertOneAsync(transporter);
}
