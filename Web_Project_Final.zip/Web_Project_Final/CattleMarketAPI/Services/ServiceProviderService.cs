using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Configuration;

namespace CattleMarketAPI.Services
{
    public class ServiceProviderService
    {
        private readonly IMongoCollection<Models.ServiceProvider> _providers;
        private readonly IConfiguration _configuration;

        public ServiceProviderService(IMongoClient mongoClient, IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
            var database = mongoClient.GetDatabase("cattle_market");
            _providers = database.GetCollection<Models.ServiceProvider>("butchers");
        }

        public async Task<List<Models.ServiceProvider>> GetAllAsync() =>
            await _providers.Find(p => true).ToListAsync();

        public async Task<Models.ServiceProvider> GetByIdAsync(string id)
        {
            return await _providers.Find(p => p.Id == id).FirstOrDefaultAsync();
        }

        public async Task<Models.ServiceProvider> GetByEmailAsync(string email)
        {
            return await _providers.Find(p => p.Email == email).FirstOrDefaultAsync();
        }

        public async Task CreateAsync(Models.ServiceProvider provider)
        {
            await _providers.InsertOneAsync(provider);
        }

        public async Task UpdateAsync(string id, Models.ServiceProvider provider)
        {
            await _providers.ReplaceOneAsync(p => p.Id == id, provider);
        }

        public async Task DeleteAsync(string id)
        {
            await _providers.DeleteOneAsync(p => p.Id == id);
        }

        public string GenerateJwtToken(Models.ServiceProvider provider)
        {
            if (string.IsNullOrWhiteSpace(provider.Id))
                throw new InvalidOperationException("Service provider Id is missing");

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, provider.Name),
                new Claim(ClaimTypes.Email, provider.Email),
                new Claim(ClaimTypes.NameIdentifier, provider.Id),
                new Claim("contact", provider.Contact ?? string.Empty)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("YourNewStrongSecretKeyHere1234567890"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "yourapp.com",
                audience: "yourapp.com",
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}