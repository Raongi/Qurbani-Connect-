using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Services
{
    public class ButcherService
    {
        private readonly IMongoCollection<Butcher> _butchers;

        public ButcherService(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market");
            _butchers = database.GetCollection<Butcher>("Butchers");
        }

        public List<Butcher> GetAllButchers()
        {
            return _butchers.Find(_ => true).ToList();
        }
    }
}
