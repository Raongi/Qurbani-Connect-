using CattleMarketAPI.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CattleMarketAPI.Services
{
    public class VehicleService
    {
        private readonly IMongoCollection<Vehicle> _vehicles;

        public VehicleService(IMongoClient mongoClient)
        {
            try
            {
                var database = mongoClient.GetDatabase("cattle_market");
                _vehicles = database.GetCollection<Vehicle>("Vehicles");
                Console.WriteLine("✅ VehicleService: MongoDB connection established");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ VehicleService: MongoDB connection failed - {ex.Message}");
                throw;
            }
        }

        public async Task<List<Vehicle>> GetAsync()
        {
            try
            {
                Console.WriteLine("📋 Fetching all vehicles...");
                var vehicles = await _vehicles.Find(v => true).ToListAsync();
                Console.WriteLine($"✅ Found {vehicles.Count} vehicles");
                return vehicles;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error fetching vehicles: {ex.Message}");
                throw;
            }
        }

        public async Task<Vehicle?> GetByIdAsync(string id)
        {
            try
            {
                Console.WriteLine($"🔍 Fetching vehicle with ID: {id}");
                var vehicle = await _vehicles.Find(v => v.Id == id).FirstOrDefaultAsync();
                
                if (vehicle == null)
                    Console.WriteLine($"⚠️ Vehicle not found with ID: {id}");
                else
                    Console.WriteLine($"✅ Vehicle found: {vehicle.MakeModel}");
                
                return vehicle;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error fetching vehicle by ID: {ex.Message}");
                throw;
            }
        }

        public async Task<Vehicle> CreateAsync(Vehicle vehicle)
        {
            try
            {
                Console.WriteLine($"➕ Creating vehicle: {vehicle.MakeModel} ({vehicle.LicensePlate})");
                
                // MongoDB will auto-generate the Id
                await _vehicles.InsertOneAsync(vehicle);
                
                Console.WriteLine($"✅ Vehicle created successfully with ID: {vehicle.Id}");
                return vehicle;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error creating vehicle: {ex.Message}");
                Console.WriteLine($"   Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task UpdateAsync(string id, Vehicle vehicle)
        {
            try
            {
                Console.WriteLine($"📝 Updating vehicle with ID: {id}");
                
                var result = await _vehicles.ReplaceOneAsync(v => v.Id == id, vehicle);
                
                if (result.ModifiedCount > 0)
                    Console.WriteLine($"✅ Vehicle updated successfully");
                else
                    Console.WriteLine($"⚠️ No vehicle was updated (ID might not exist)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error updating vehicle: {ex.Message}");
                throw;
            }
        }

        public async Task DeleteAsync(string id)
        {
            try
            {
                Console.WriteLine($"🗑️ Deleting vehicle with ID: {id}");
                
                var result = await _vehicles.DeleteOneAsync(v => v.Id == id);
                
                if (result.DeletedCount > 0)
                    Console.WriteLine($"✅ Vehicle deleted successfully");
                else
                    Console.WriteLine($"⚠️ No vehicle was deleted (ID might not exist)");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error deleting vehicle: {ex.Message}");
                throw;
            }
        }
    }
}