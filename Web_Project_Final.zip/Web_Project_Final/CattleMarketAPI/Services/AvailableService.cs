using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Services
{
    public class AvailableService
    {
        private readonly IMongoCollection<Available> _available;

        public AvailableService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("cattle_market");
            _available = database.GetCollection<Available>("Available");

            Console.WriteLine("✅ AvailableService: MongoDB connection established");
        }

        public async Task<List<Available>> GetAsync(string? plate = null)
        {
            if (string.IsNullOrEmpty(plate))
                return await _available.Find(_ => true).ToListAsync();

            return await _available
                .Find(a => a.VehiclePlate == plate)
                .ToListAsync();
        }

        public async Task CreateAsync(Available available)
        {
            await _available.InsertOneAsync(available);
        }
    }
}
