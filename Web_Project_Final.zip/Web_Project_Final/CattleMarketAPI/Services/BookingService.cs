using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace CattleMarketAPI.Services
{
    public class BookingService
    {
        private readonly IMongoCollection<Booking> _bookings;

        public BookingService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("cattle_market");
            _bookings = database.GetCollection<Booking>("bookings");
        }

        public async Task<List<Booking>> GetAllAsync() =>
            await _bookings.Find(b => true).ToListAsync();

        public async Task<Booking> GetByIdAsync(string id) =>
            await _bookings.Find(b => b.Id == id).FirstOrDefaultAsync();

        public async Task<List<Booking>> GetByProviderIdAsync(string providerId) =>
            await _bookings.Find(b => b.ServiceProviderId == providerId).ToListAsync();

        public async Task CreateAsync(Booking booking)
        {
            await _bookings.InsertOneAsync(booking);
        }

        public async Task UpdateAsync(string id, Booking booking)
        {
            booking.UpdatedAt = DateTime.Now;
            await _bookings.ReplaceOneAsync(b => b.Id == id, booking);
        }

        public async Task DeleteAsync(string id)
        {
            await _bookings.DeleteOneAsync(b => b.Id == id);
        }

        public async Task UpdateStatusAsync(string id, string status)
        {
            var update = Builders<Booking>.Update
                .Set(b => b.Status, status)
                .Set(b => b.UpdatedAt, DateTime.Now);
            
            await _bookings.UpdateOneAsync(b => b.Id == id, update);
        }
    }
}