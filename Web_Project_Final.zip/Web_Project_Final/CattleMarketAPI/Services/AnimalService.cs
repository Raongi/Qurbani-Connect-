using CattleMarketAPI.Models;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CattleMarketAPI.Services
{
    public class AnimalService
    {
        private readonly IMongoCollection<Animal> _animals;

        public AnimalService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("cattle_market");
            _animals = database.GetCollection<Animal>("Animals");
        }

        public async Task<List<Animal>> GetAllAsync() =>
            await _animals.Find(_ => true).ToListAsync();

        public async Task<Animal> GetByIdAsync(string id) =>
            await _animals.Find(a => a.Id == id).FirstOrDefaultAsync();

        public async Task CreateAsync(Animal animal) =>
            await _animals.InsertOneAsync(animal);

       public async Task UpdateAsync(string id, Animal animal)
{
    // Fetch existing animal
    var existing = await _animals.Find(a => a.Id == id).FirstOrDefaultAsync();
    if (existing == null) return;

    // Keep the same Id
    animal.Id = existing.Id;

    await _animals.ReplaceOneAsync(a => a.Id == id, animal);
}

   // Add this new method
      public async Task<Animal> FetchAnimalByIdAsync(string id) =>
           await _animals.Find(a => a.Id == id).FirstOrDefaultAsync();

        public async Task DeleteAsync(string id) =>
            await _animals.DeleteOneAsync(a => a.Id == id);
    }
}
