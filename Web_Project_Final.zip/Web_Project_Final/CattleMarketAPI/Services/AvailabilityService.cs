using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace CattleMarketAPI.Services
{
    public class AvailabilityService
    {
        private readonly IMongoCollection<Availability> _availabilities;

        public AvailabilityService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("cattle_market");
            _availabilities = database.GetCollection<Availability>("availability");
        }

        public async Task<List<Availability>> GetAllAsync() =>
            await _availabilities.Find(a => true).ToListAsync();

        public async Task<Availability> GetByIdAsync(string id) =>
            await _availabilities.Find(a => a.Id == id).FirstOrDefaultAsync();

        public async Task<List<Availability>> GetByProviderIdAsync(string providerId) =>
            await _availabilities.Find(a => a.ServiceProviderId == providerId).ToListAsync();

        public async Task<List<Availability>> GetAvailableSlotsAsync() =>
            await _availabilities.Find(a => a.Status == "available").ToListAsync();

        public async Task CreateAsync(Availability availability)
        {
            await _availabilities.InsertOneAsync(availability);
        }

        public async Task UpdateAsync(string id, Availability availability)
        {
            availability.UpdatedAt = DateTime.Now;
            await _availabilities.ReplaceOneAsync(a => a.Id == id, availability);
        }

        public async Task DeleteAsync(string id)
        {
            await _availabilities.DeleteOneAsync(a => a.Id == id);
        }

        public async Task UpdateStatusAsync(string id, string status)
        {
            var update = Builders<Availability>.Update
                .Set(a => a.Status, status)
                .Set(a => a.UpdatedAt, DateTime.Now);
            
            await _availabilities.UpdateOneAsync(a => a.Id == id, update);
        }
    }
}