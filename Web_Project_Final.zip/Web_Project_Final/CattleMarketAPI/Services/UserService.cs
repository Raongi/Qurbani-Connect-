using MongoDB.Driver;
using CattleMarketAPI.Models;
using System.Threading.Tasks;

public class UserService
{
    private readonly IMongoCollection<User> _users;

    public UserService(IMongoClient mongoClient)
    {
        var database = mongoClient.GetDatabase("cattle_market");
        _users = database.GetCollection<User>("Users");
    }

    public async Task<User> GetByEmailAsync(string email)
    {
        return await _users.Find(u => u.Email == email).FirstOrDefaultAsync();
    }

    public async Task<User> GetByUserIdAsync(string userId)
    {
        return await _users.Find(u => u.UserId == userId).FirstOrDefaultAsync();
    }

    public async Task<long> CountAsync()
    {
        return await _users.CountDocumentsAsync(u => true);
    }

    public async Task CreateAsync(User user)
    {
        await _users.InsertOneAsync(user);
    }
}
