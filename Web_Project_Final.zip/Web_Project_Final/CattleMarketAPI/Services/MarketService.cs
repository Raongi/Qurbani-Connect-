using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Services
{
    public class MarketService
    {
        private readonly IMongoCollection<Market> _markets;

        public MarketService(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market");
            _markets = database.GetCollection<Market>("sellers");
        }

        public List<Market> GetAllMarkets()
        {
            return _markets.Find(_ => true).ToList();
        }
    }
}
