using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using MongoDB.Driver;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Single MongoClient for all services
var mongoConnection = "mongodb://localhost:27017"; // Or use builder.Configuration
builder.Services.AddSingleton<IMongoClient>(s => new MongoClient(mongoConnection));

// Add application services
builder.Services.AddScoped<SellerService>();
builder.Services.AddScoped<AnimalService>();
builder.Services.AddScoped<OrderService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<MarketService>();
builder.Services.AddScoped<ButcherService>();
builder.Services.AddScoped<TransporterService>();
// Program.cs mein add karo
builder.Services.AddSingleton<OrderBookingService>();
builder.Services.AddSingleton<TransportService>();
builder.Services.AddSingleton<VehicleService>();
builder.Services.AddScoped<AvailableService>();
builder.Services.AddScoped<ServiceProviderService>();
builder.Services.AddScoped<AvailabilityService>();
builder.Services.AddScoped<BookingService>();
// ✅ DISABLE AUTOMATIC MODEL VALIDATION
builder.Services.AddControllers()
    .ConfigureApiBehaviorOptions(options =>
    {
        options.SuppressModelStateInvalidFilter = true;  // ← YEH LINE ADD KAREIN
    });
// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
// ✅ CORS for Live Server
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy
            .AllowAnyOrigin()  // ✅ SAHI
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// ✅ JWT Authentication (required for [Authorize])
// Many controllers/services currently sign tokens with this secret.
var jwtSecret = "YourNewStrongSecretKeyHere1234567890";

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
            ValidateIssuer = false,
            ValidateAudience = false,
            ClockSkew = TimeSpan.Zero
        };
    });

builder.Services.AddAuthorization();
// CORS for Development
var app = builder.Build();
app.UseStaticFiles();
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(
        @"C:\Users\RABIA\Desktop\Web_Project_Final"),
    RequestPath = ""
});
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(
        @"C:\Users\RABIA\Desktop\Web_Project_Final\images"), // only images folder
    RequestPath = "/images" // this becomes your URL prefix
});
// Swagger
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ✅ IMPORTANT ORDER
app.UseRouting();
app.UseCors("AllowAll");
app.UseAuthentication();
app.UseAuthorization();
// Optional: comment temporarily if you use HTTP fetch
// app.UseHttpsRedirection(); 

app.MapControllers();

app.Run();
