namespace CattleMarketAPI.DTOs
{
    public class CreateBookingFromAvailabilityDto
    {
        public string AvailabilityId { get; set; }
    }
}