using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CattleMarketAPI.DTOs
{
    public class JoinDto
    {
        public string AvailabilityId { get; set; }
    }
}