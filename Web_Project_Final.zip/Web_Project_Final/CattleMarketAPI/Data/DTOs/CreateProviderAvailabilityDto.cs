namespace CattleMarketAPI.Data.DTOs
{
    public class CreateProviderAvailabilityDto
    {
        public string AvailableDate { get; set; } = string.Empty;
        public string TimeSlot { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public string ServiceType { get; set; } = string.Empty;
        public double PriceRange { get; set; }
        public string SpaceAvailable { get; set; } = string.Empty;
        public string StartTime { get; set; } = "08:00";
        public string EndTime { get; set; } = "18:00";
        public List<string> Days { get; set; } = new();
        public string Status { get; set; } = "available";
    }
}
