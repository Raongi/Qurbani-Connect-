using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using System.Text;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;

[ApiController]
[Route("api/user")]
public class UserController : ControllerBase
{
    private readonly UserService _userService;

    public UserController(UserService userService)
    {
        _userService = userService;
    }

   [HttpPost("register")]
public async Task<IActionResult> Register([FromBody] User user)
{
    var existingUser = await _userService.GetByEmailAsync(user.Email);
    if (existingUser != null)
        return BadRequest(new { message = "Email already exists" });

    // Count existing users
    var count = await _userService.CountAsync();
    user.UserId = $"USR-{(count + 1).ToString("D4")}"; // USR-0001, USR-0002 ...

    await _userService.CreateAsync(user);
    return Ok(new { message = "User registered successfully", userId = user.UserId });
}
[HttpPost("login")]
public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
{
    var user = await _userService.GetByEmailAsync(loginModel.Email);
    if (user == null)
        return Unauthorized(new { message = "Invalid email or password" });

    // Password check (agar plain text use kar rahe ho)
    if (user.Password != loginModel.Password) 
        return Unauthorized(new { message = "Invalid email or password" });

    // JWT Token generate
    var tokenHandler = new JwtSecurityTokenHandler();
    var key = Encoding.ASCII.GetBytes("YourNewStrongSecretKeyHere1234567890"); // same as Seller secret
    var tokenDescriptor = new SecurityTokenDescriptor
    {
        Subject = new ClaimsIdentity(new Claim[]
        {
            new Claim(ClaimTypes.Name, user.FirstName + " " + user.LastName),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.NameIdentifier, user.UserId)
        }),
        Expires = DateTime.UtcNow.AddHours(1),
        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
    };
    var token = tokenHandler.CreateToken(tokenDescriptor);
    var tokenString = tokenHandler.WriteToken(token);

    return Ok(new { message = "Login successful", token = tokenString, userId = user.UserId });
    
}
}