using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ButcherController : ControllerBase
    {
        private readonly IMongoCollection<Butcher> _butchers;

        public ButcherController(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market"); // Your DB name
            _butchers = database.GetCollection<Butcher>("Butchers"); // Your collection
        }

        [HttpGet]
        public IActionResult GetButchers()
        {
            try
            {
                var butchers = _butchers.Find(_ => true).ToList();
                return Ok(butchers); // returns JSON
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message }); // returns JSON error
            }
        }
    }
}
