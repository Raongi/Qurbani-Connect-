using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using CattleMarketAPI.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/butcher-availability")]
    public class ButcherAvailabilityController : ControllerBase
    {
        private readonly IMongoCollection<Availability> _availabilities;

        public ButcherAvailabilityController(IMongoClient client)
        {
            var db = client.GetDatabase("cattle_market");
            _availabilities = db.GetCollection<Availability>("availability");
        }

        public class ButcherAvailabilityCalendarItem
        {
            public string? Id { get; set; }
            public string? ButcherId { get; set; }
            public string ButcherName { get; set; } = string.Empty;
            public string Date { get; set; } = string.Empty;
            public string TimeSlot { get; set; } = string.Empty;
            public string StartTime { get; set; } = string.Empty;
            public string EndTime { get; set; } = string.Empty;
            public string Location { get; set; } = string.Empty;
            public string ServiceType { get; set; } = string.Empty;
            public double PriceRange { get; set; }
            public string SpaceAvailable { get; set; } = string.Empty;
            public string Status { get; set; } = "available";
        }

        [HttpGet("calendar")]
        public async Task<IActionResult> Calendar([FromQuery] int days = 7)
        {
            if (days < 1) days = 7;
            if (days > 14) days = 14;

            var from = DateTime.UtcNow.Date;
            var to = from.AddDays(days);

            var fromStr = from.ToString("yyyy-MM-dd");
            var toStr = to.ToString("yyyy-MM-dd");

            // Some older documents may have missing/empty AvailableDate, which can cause null errors.
            var filter = Builders<Availability>.Filter.And(
                Builders<Availability>.Filter.Ne(a => a.AvailableDate, null),
                Builders<Availability>.Filter.Ne(a => a.AvailableDate, string.Empty),
                Builders<Availability>.Filter.Gte(a => a.AvailableDate, fromStr),
                Builders<Availability>.Filter.Lte(a => a.AvailableDate, toStr)
            );

            var list = await _availabilities.Find(filter).ToListAsync();

            var result = list
                .Select(a => new ButcherAvailabilityCalendarItem
                {
                    Id = a.Id,
                    ButcherId = a.ButcherId ?? a.ServiceProviderId,
                    ButcherName = string.IsNullOrWhiteSpace(a.ButcherName) ? "Unknown" : a.ButcherName,
                    Date = a.AvailableDate ?? string.Empty,
                    TimeSlot = a.TimeSlot ?? string.Empty,
                    StartTime = a.StartTime ?? string.Empty,
                    EndTime = a.EndTime ?? string.Empty,
                    Location = a.Location ?? string.Empty,
                    ServiceType = a.ServiceType ?? string.Empty,
                    PriceRange = a.PriceRange,
                    SpaceAvailable = a.SpaceAvailable ?? string.Empty,
                    Status = string.IsNullOrWhiteSpace(a.Status) ? "available" : a.Status
                })
                .ToList();

            return Ok(result);
        }
    }
}