using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransportersController : ControllerBase
    {
        private readonly IMongoCollection<Transporter> _transporters;

        public TransportersController(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market");
            _transporters = database.GetCollection<Transporter>("Transporters");
        }

        [HttpGet]
        public IActionResult GetTransporters()
        {
            try
            {
                var transporters = _transporters.Find(_ => true).ToList();
                return Ok(transporters);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
