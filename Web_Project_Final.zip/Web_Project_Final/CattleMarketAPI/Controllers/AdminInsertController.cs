using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/admin")]
    [AllowAnonymous] // keep demo-friendly; later you can switch to [Authorize]
    public class AdminLegacyController : ControllerBase
    {
        private readonly IMongoDatabase _db;

        public AdminLegacyController(IMongoClient client)
        {
            _db = client.GetDatabase("cattle_market");
        }

        private static string Get(BsonDocument d, params string[] keys)
        {
            foreach (var k in keys)
            {
                if (d.Contains(k) && !d[k].IsBsonNull) return d[k].ToString() ?? "";
            }
            return "";
        }

        private static object MapDoc(BsonDocument d)
        {
            var id = d.Contains("_id") ? d["_id"].ToString() : "";

            var firstName = Get(d, "FirstName", "firstName");
            var lastName = Get(d, "LastName", "lastName");
            var combinedName = $"{firstName} {lastName}".Trim();

            var fullName = !string.IsNullOrWhiteSpace(combinedName)
                ? combinedName
                : Get(d, "FullName", "fullName", "Name", "name", "farmerName", "FarmerName", "UserName", "userName");

            return new
            {
                id,
                fullName,
                email = Get(d, "Email", "email"),
                phone = Get(d, "Phone", "phone", "PhoneNumber", "phoneNumber", "Mobile", "mobile", "Contact", "contact", "ContactNo", "contactNo"),
                location = Get(d, "Location", "location", "City", "city", "Address", "address"),
                specialization = Get(d, "Specialization", "specialization", "ServiceType", "serviceType"),
                city = Get(d, "City", "city"),
                address = Get(d, "Address", "address"),
                animalsCount = Get(d, "AnimalsCount", "animalsCount"),
                createdAt = Get(d, "CreatedAt", "createdAt")
            };
        }

        private async Task<List<object>> ReadMany(params string[] collectionNames)
        {
            var list = new List<object>();

            foreach (var name in collectionNames)
            {
                var col = _db.GetCollection<BsonDocument>(name);
                var docs = await col.Find(FilterDefinition<BsonDocument>.Empty).ToListAsync();
                list.AddRange(docs.Select(MapDoc));
            }

            return list;
        }

        // ✅ FRONTEND: GET /api/admin/seller
        [HttpGet("seller")]
        public async Task<IActionResult> GetSellers()
        {
            var result = await ReadMany("Seller");
            return Ok(new { sellers = result, count = result.Count });
        }

        // ✅ FRONTEND: GET /api/admin/transport  (if your pages call it)
        [HttpGet("transport")]
        public async Task<IActionResult> GetTransporters()
        {
            // Transporters often store only basic info; vehicle data is stored in Vehicles
            // (linked by transporterEmail). Enrich the response so admin UI can show
            // vehicleType + licensePlate.
            var transporterCollections = new[] { "transporter", "transporters", "Transporter" };

            var vehiclesCol = _db.GetCollection<BsonDocument>("Vehicles");
            var transporters = new List<object>();

            foreach (var colName in transporterCollections)
            {
                var col = _db.GetCollection<BsonDocument>(colName);
                var docs = await col.Find(FilterDefinition<BsonDocument>.Empty).ToListAsync();

                foreach (var d in docs)
                {
                    var id = d.Contains("_id") ? d["_id"].ToString() : "";

                    var firstName = Get(d, "FirstName", "firstName");
                    var lastName = Get(d, "LastName", "lastName");
                    var combinedName = $"{firstName} {lastName}".Trim();

                    var fullName = !string.IsNullOrWhiteSpace(combinedName)
                        ? combinedName
                        : Get(d, "FullName", "fullName", "TransporterName", "transporterName", "Name", "name", "FarmerName", "farmerName", "UserName", "userName");

                    var email = Get(d, "Email", "email", "TransporterEmail", "transporterEmail");
                    var phone = Get(d, "Phone", "phone", "PhoneNumber", "phoneNumber", "Mobile", "mobile", "Contact", "contact", "ContactNo", "contactNo");
                    var location = Get(d, "Location", "location", "City", "city", "Address", "address");
                    var createdAt = Get(d, "CreatedAt", "createdAt");

                    string vehicleType = Get(d, "VehicleType", "vehicleType");
                    string licensePlate = Get(d, "LicensePlate", "licensePlate", "LicenseNumber", "licenseNumber");

                    if (!string.IsNullOrWhiteSpace(email) && (string.IsNullOrWhiteSpace(vehicleType) || string.IsNullOrWhiteSpace(licensePlate)))
                    {
                        // Do not force lowercase here; match what is stored in Mongo.
                        var vFilter = Builders<BsonDocument>.Filter.Eq("transporterEmail", email.Trim());
                        var vDoc = await vehiclesCol.Find(vFilter)
                            .Sort(Builders<BsonDocument>.Sort.Descending("createdAt"))
                            .FirstOrDefaultAsync();

                        if (vDoc != null)
                        {
                            if (string.IsNullOrWhiteSpace(vehicleType))
                                vehicleType = Get(vDoc, "vehicleType", "VehicleType");
                            if (string.IsNullOrWhiteSpace(licensePlate))
                                licensePlate = Get(vDoc, "licensePlate", "LicensePlate");
                        }
                    }

                    transporters.Add(new
                    {
                        id,
                        fullName,
                        email,
                        phone,
                        location,
                        createdAt,
                        vehicleType,
                        licensePlate,
                        // Back-compat for any older frontend expecting licenseNumber
                        licenseNumber = licensePlate
                    });
                }
            }

            return Ok(new { transporters, count = transporters.Count });
        }

        // ✅ FRONTEND: GET /api/admin/butchers
        [HttpGet("butchers")]
        public async Task<IActionResult> GetButchers()
        {
            var result = await ReadMany("butchers");
            return Ok(new { butchers = result, count = result.Count });
        }

        // ✅ FRONTEND: GET /api/admin/users  (your users.html 404)
        [HttpGet("users")]
        [HttpGet("user")] // some pages use /user
        public async Task<IActionResult> GetUsers()
        {
            var result = await ReadMany("users", "Users", "user");
            return Ok(new { users = result, count = result.Count });
        }
    }
}