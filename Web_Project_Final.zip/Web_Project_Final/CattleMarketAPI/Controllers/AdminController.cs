using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MongoDB.Bson;
using MongoDB.Driver;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/admin")]
    public class AdminController : ControllerBase
    {
        private readonly IMongoCollection<BsonDocument> _admins;

        // same key as your project
        private const string JWT_SECRET_KEY = "YourNewStrongSecretKeyHere1234567890";

        public AdminController(IMongoClient client)
        {
            // IMPORTANT: ensure DB name matches your MongoDB
            var db = client.GetDatabase("cattle_market");
            _admins = db.GetCollection<BsonDocument>("admins");
        }

        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterAdminDto dto)
        {
            try
            {
                if (dto == null)
                    return BadRequest(new { message = "Body is required" });

                var fullName = (dto.FullName ?? "").Trim();
                var email = (dto.Email ?? "").Trim().ToLowerInvariant();
                var password = dto.Password ?? "";

                if (string.IsNullOrWhiteSpace(fullName) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                    return BadRequest(new { message = "FullName, Email, Password are required" });

                var existing = await _admins.Find(Builders<BsonDocument>.Filter.Eq("Email", email)).FirstOrDefaultAsync();
                if (existing != null)
                    return BadRequest(new { message = "Email already exists" });

                var adminDoc = new BsonDocument
                {
                    { "FullName", fullName },
                    { "Email", email },
                    { "Password", password }, // demo only
                    { "CreatedAt", DateTime.UtcNow }
                };

                await _admins.InsertOneAsync(adminDoc);

                var id = adminDoc.GetValue("_id").ToString();
                return Ok(new { message = "Admin registered successfully", adminId = id });
            }
            catch (Exception ex)
            {
                // always JSON (so frontend response.json() won't crash)
                return StatusCode(500, new { message = "Server error during registration", detail = ex.Message });
            }
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            try
            {
                if (dto == null)
                    return BadRequest(new { message = "Body is required" });

                var email = (dto.Email ?? "").Trim().ToLowerInvariant();
                var password = dto.Password ?? "";

                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                    return BadRequest(new { message = "Email and Password are required" });

                var admin = await _admins.Find(Builders<BsonDocument>.Filter.Eq("Email", email)).FirstOrDefaultAsync();
                if (admin == null)
                    return Unauthorized(new { message = "Invalid email or password" });

                var savedPassword = admin.GetValue("Password", "").ToString();
                if (!string.Equals(savedPassword, password, StringComparison.Ordinal))
                    return Unauthorized(new { message = "Invalid email or password" });

                var adminId = admin.GetValue("_id").ToString();
                var fullName = admin.GetValue("FullName", "Admin").ToString();

                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(JWT_SECRET_KEY);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, adminId),
                        new Claim(ClaimTypes.Email, email),
                        new Claim(ClaimTypes.Name, fullName),
                        new Claim("role", "admin")
                    }),
                    Expires = DateTime.UtcNow.AddHours(24),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return Ok(new
                {
                    message = "Login successful",
                    token = tokenString,
                    adminId = adminId,
                    fullName = fullName,
                    email = email
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Server error during login", detail = ex.Message });
            }
        }

        // keep this separate (no duplicate route)
        [HttpPost("direct-login")]
        [AllowAnonymous]
        public async Task<IActionResult> DirectLogin([FromBody] DirectLoginDto dto)
        {
            try
            {
                var email = (dto?.Email ?? "").Trim().ToLowerInvariant();
                if (string.IsNullOrWhiteSpace(email))
                    return BadRequest(new { message = "Email is required" });

                var admin = await _admins.Find(Builders<BsonDocument>.Filter.Eq("Email", email)).FirstOrDefaultAsync();
                if (admin == null)
                {
                    var adminDoc = new BsonDocument
                    {
                        { "FullName", (dto?.FullName ?? "Admin").Trim() },
                        { "Email", email },
                        { "Password", "default123" },
                        { "CreatedAt", DateTime.UtcNow }
                    };
                    await _admins.InsertOneAsync(adminDoc);
                    admin = adminDoc;
                }

                var adminId = admin.GetValue("_id").ToString();
                var fullName = admin.GetValue("FullName", "Admin").ToString();

                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.UTF8.GetBytes(JWT_SECRET_KEY);

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, adminId),
                        new Claim(ClaimTypes.Email, email),
                        new Claim(ClaimTypes.Name, fullName),
                        new Claim("role", "admin")
                    }),
                    Expires = DateTime.UtcNow.AddHours(24),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };

                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                return Ok(new { message = "Login successful", token = tokenString, adminId, fullName, email });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Server error during direct login", detail = ex.Message });
            }
        }
 private static FilterDefinition<BsonDocument> BuildAdminFilter(string? adminId, string? email)
        {
            if (!string.IsNullOrWhiteSpace(adminId) && ObjectId.TryParse(adminId, out var oid))
                return Builders<BsonDocument>.Filter.Eq("_id", oid);

            if (!string.IsNullOrWhiteSpace(email))
                return Builders<BsonDocument>.Filter.Eq("Email", email.Trim().ToLowerInvariant());

            return Builders<BsonDocument>.Filter.Empty;
        }

        private static object ToProfileDto(BsonDocument admin)
        {
            return new
            {
                adminId = admin.GetValue("_id").ToString(),
                fullName = admin.GetValue("FullName", "Admin").ToString(),
                email = admin.GetValue("Email", "").ToString(),
                phone = admin.Contains("Phone") ? admin["Phone"].ToString() : "",
                location = admin.Contains("Location") ? admin["Location"].ToString() : "",
                createdAt = admin.Contains("CreatedAt") ? admin["CreatedAt"].ToString() : ""
            };
        }

        private async Task<BsonDocument?> FindAdminOrFirstAsync(string? adminId, string? email)
        {
            var filter = BuildAdminFilter(adminId, email);

            if (filter != Builders<BsonDocument>.Filter.Empty)
                return await _admins.Find(filter).FirstOrDefaultAsync();

            // ✅ demo-friendly fallback: if frontend doesn't send id/email, return the first admin
            return await _admins.Find(FilterDefinition<BsonDocument>.Empty).FirstOrDefaultAsync();
        }

        private static string? Q(HttpRequest req, string key)
            => req.Query.ContainsKey(key) ? req.Query[key].ToString() : null;

        // GET /api/admin/profile  (now works even if frontend sends nothing)
        [HttpGet("profile")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProfile([FromQuery] string? adminId, [FromQuery] string? email)
        {
            try
            {
                adminId ??= Q(Request, "adminId");
                email ??= Q(Request, "email");

                var admin = await FindAdminOrFirstAsync(adminId, email);
                if (admin == null)
                    return NotFound(new { message = "Admin not found" });

                return Ok(new { profile = ToProfileDto(admin) });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Server error while loading profile", detail = ex.Message });
            }
        }

        // ✅ SUPPORT frontend route: /api/admin/profile/update (PUT or POST)
        [HttpPut("profile/update")]
        [HttpPost("profile/update")]
        [AllowAnonymous]
        public Task<IActionResult> UpdateProfileAlias([FromBody] UpdateAdminProfileDto dto)
            => UpdateProfile(dto);

        // PUT /api/admin/profile (main)
        [HttpPut("profile")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateAdminProfileDto dto)
        {
            try
            {
                if (dto == null)
                    return BadRequest(new { message = "Body is required" });

                // allow also querystring values if frontend uses them
                dto.AdminId ??= Q(Request, "adminId");
                dto.Email ??= Q(Request, "email");

                // find admin (or first)
                var admin = await FindAdminOrFirstAsync(dto.AdminId, dto.Email);
                if (admin == null)
                    return NotFound(new { message = "Admin not found" });

                var filter = Builders<BsonDocument>.Filter.Eq("_id", admin["_id"]);

                var updates = new List<UpdateDefinition<BsonDocument>>();

                if (!string.IsNullOrWhiteSpace(dto.FullName))
                    updates.Add(Builders<BsonDocument>.Update.Set("FullName", dto.FullName.Trim()));

                if (!string.IsNullOrWhiteSpace(dto.Phone))
                    updates.Add(Builders<BsonDocument>.Update.Set("Phone", dto.Phone.Trim()));

                if (!string.IsNullOrWhiteSpace(dto.Location))
                    updates.Add(Builders<BsonDocument>.Update.Set("Location", dto.Location.Trim()));

                if (updates.Count == 0)
                    return BadRequest(new { message = "Nothing to update" });

                await _admins.UpdateOneAsync(filter, Builders<BsonDocument>.Update.Combine(updates));

                var updated = await _admins.Find(filter).FirstOrDefaultAsync();
                return Ok(new { message = "Profile updated", profile = updated == null ? null : ToProfileDto(updated) });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Server error while updating profile", detail = ex.Message });
            }
        }

        // POST /api/admin/change-password (now also works without adminId/email by using first admin)
        [HttpPost("change-password")]
        [AllowAnonymous]
        public async Task<IActionResult> ChangePassword([FromBody] ChangeAdminPasswordDto dto)
        {
            try
            {
                if (dto == null)
                    return BadRequest(new { message = "Body is required" });

                dto.AdminId ??= Q(Request, "adminId");
                dto.Email ??= Q(Request, "email");

                if (string.IsNullOrWhiteSpace(dto.CurrentPassword) || string.IsNullOrWhiteSpace(dto.NewPassword))
                    return BadRequest(new { message = "CurrentPassword and NewPassword are required" });

                var admin = await FindAdminOrFirstAsync(dto.AdminId, dto.Email);
                if (admin == null)
                    return NotFound(new { message = "Admin not found" });

                var savedPassword = admin.GetValue("Password", "").ToString();
                if (!string.Equals(savedPassword, dto.CurrentPassword, StringComparison.Ordinal))
                    return BadRequest(new { message = "Current password is incorrect" });

                var filter = Builders<BsonDocument>.Filter.Eq("_id", admin["_id"]);
                await _admins.UpdateOneAsync(filter, Builders<BsonDocument>.Update.Set("Password", dto.NewPassword));

                return Ok(new { message = "Password updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Server error while changing password", detail = ex.Message });
            }
        }
    }

    public class UpdateAdminProfileDto
    {
        public string? AdminId { get; set; }
        public string? Email { get; set; }
        public string? FullName { get; set; }
        public string? Phone { get; set; }
        public string? Location { get; set; }
    }

    public class ChangeAdminPasswordDto
    {
        public string? AdminId { get; set; }
        public string? Email { get; set; }
        public string? CurrentPassword { get; set; }
        public string? NewPassword { get; set; }
    }

    public class RegisterAdminDto
    {
        public string? FullName { get; set; }
        public string? Email { get; set; }
        public string? Password { get; set; }
    }

    public class LoginDto
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }

    public class DirectLoginDto
    {
        public string? Email { get; set; }
        public string? FullName { get; set; }
    }
}