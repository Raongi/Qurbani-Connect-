using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using CattleMarketAPI.DTOs;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using System;
using System.Threading.Tasks;
using System.Linq;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/bookings")]
    public class BookingsFromAvailabilityController : ControllerBase
    {
        private readonly BookingService _bookingService;
        private readonly AvailabilityService _availabilityService;
        private readonly UserService _userService;

        public BookingsFromAvailabilityController(
            BookingService bookingService,
            AvailabilityService availabilityService,
            UserService userService)
        {
            _bookingService = bookingService;
            _availabilityService = availabilityService;
            _userService = userService;
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> GetMyBookings()
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var userName = User.FindFirst(ClaimTypes.Name)?.Value;

                if (string.IsNullOrEmpty(userId))
                    return Unauthorized(new { message = "Invalid user token" });

                var allBookings = await _bookingService.GetAllAsync();
                var myBookings = allBookings
                    .Where(b => b.CustomerName == userName || b.CustomerEmail == User.FindFirst(ClaimTypes.Email)?.Value)
                    .ToList();

                return Ok(myBookings);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [Authorize]
        [HttpPost("from-availability")]
        public async Task<IActionResult> CreateFromAvailability([FromBody] CreateBookingFromAvailabilityDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.AvailabilityId))
                return BadRequest(new { message = "AvailabilityId is required" });

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userName = User.FindFirst(ClaimTypes.Name)?.Value ?? "N/A";
            var userEmail = User.FindFirst(ClaimTypes.Email)?.Value ?? string.Empty;

            if (string.IsNullOrEmpty(userId))
                return Unauthorized(new { message = "Invalid user token" });

            var availability = await _availabilityService.GetByIdAsync(dto.AvailabilityId);
            if (availability == null)
                return NotFound(new { message = "Availability slot not found" });

            if (!string.Equals(availability.Status, "available", StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { message = "Slot is not available" });

            // Get contact/address from DB (token has id + name + email only)
            var user = await _userService.GetByUserIdAsync(userId);
            var userContact = user?.Phone ?? userEmail;
            var userAddress = user?.Address ?? string.Empty;

            var booking = new Booking
            {
                AvailabilityId = availability.Id ?? dto.AvailabilityId,
                ServiceProviderId = availability.ButcherId ?? availability.ServiceProviderId ?? string.Empty,

                CustomerName = userName,
                CustomerEmail = userEmail,
                CustomerContact = userContact,
                CustomerAddress = userAddress,

                BookingDate = DateTime.UtcNow,
                TimeSlot = string.IsNullOrWhiteSpace(availability.TimeSlot)
                    ? $"{availability.StartTime} - {availability.EndTime}".Trim(' ', '-')
                    : availability.TimeSlot,
                ServiceType = availability.ServiceType,
                Status = "pending",
                Price = (decimal)availability.PriceRange,

                SpecialRequirements = string.IsNullOrWhiteSpace(availability.SpaceAvailable)
                    ? string.Empty
                    : $"Space: {availability.SpaceAvailable}"
            };

            await _bookingService.CreateAsync(booking);
            await _availabilityService.UpdateStatusAsync(dto.AvailabilityId, "booked");

            return Ok(new { message = "Booked successfully", bookingId = booking.Id });
        }
    }
}