using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using System.Security.Claims;
using CattleMarketAPI.DTOs;
using CattleMarketAPI.Models;
using System;
using System.Threading.Tasks;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/service-bookings")]
    public class ServiceBookingsController : ControllerBase
    {
        private readonly IMongoCollection<ServiceBooking> _bookings;
        private readonly IMongoCollection<ButcherAvailabilitySlot> _slots;

        public ServiceBookingsController(IMongoClient client)
        {
            var db = client.GetDatabase("cattle_market");
            _bookings = db.GetCollection<ServiceBooking>("ServiceBookings");
            _slots = db.GetCollection<ButcherAvailabilitySlot>("ButcherAvailability");
        }

        // POST: api/service-bookings
        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateServiceBookingDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.AvailabilityId))
                return BadRequest(new { message = "AvailabilityId is required" });

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userName = User.FindFirst(ClaimTypes.Name)?.Value ?? "N/A";
            var userContact = User.FindFirst(ClaimTypes.Email)?.Value ?? "N/A"; // contact from token

            if (string.IsNullOrEmpty(userId))
                return Unauthorized(new { message = "Invalid user token" });

            var slot = await _slots.Find(s => s.Id == dto.AvailabilityId).FirstOrDefaultAsync();
            if (slot == null)
                return NotFound(new { message = "Availability slot not found" });

            if (!string.Equals(slot.Status, "Available", StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { message = "This slot is not available" });

            // Mark slot booked
            slot.Status = "Booked";
            await _slots.ReplaceOneAsync(s => s.Id == slot.Id, slot);

            // Save booking
            var booking = new ServiceBooking
            {
                AvailabilityId = slot.Id,

                UserId = userId,
                UserName = userName,
                UserContact = userContact,

                ButcherId = slot.ButcherId,
                ButcherName = slot.ButcherName,

                Date = slot.Date,
                StartTime = slot.StartTime,
                EndTime = slot.EndTime,
                Location = slot.Location,

                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            await _bookings.InsertOneAsync(booking);

            return Ok(new { message = "Booked successfully", bookingId = booking.Id });
        }

        // GET: api/service-bookings
        // (for admin/testing; you can later filter by userId/butcherId)
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var list = await _bookings.Find(_ => true)
                .SortByDescending(b => b.CreatedAt)
                .ToListAsync();

            return Ok(list);
        }
    }
}