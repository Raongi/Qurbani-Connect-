using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using CattleMarketAPI.Data.DTOs;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using BCrypt.Net;
using System;
using ServiceProvider = CattleMarketAPI.Models.ServiceProvider;

namespace CattleMarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceProviderController : ControllerBase
    {
        private readonly ServiceProviderService _providerService;
        private readonly AvailabilityService _availabilityService;
        private readonly IConfiguration _configuration;

        public ServiceProviderController(ServiceProviderService providerService, AvailabilityService availabilityService, IConfiguration configuration)
        {
            _providerService = providerService;
            _availabilityService = availabilityService;
            _configuration = configuration;
        }

        private string? GetProviderIdFromToken()
        {
            var token = Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);
                return jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            }
            catch
            {
                return null;
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] ServiceProvider provider)
        {
            try
            {
                if (string.IsNullOrEmpty(provider.Email) || string.IsNullOrEmpty(provider.Password))
                {
                    return BadRequest(new { message = "Email and password are required" });
                }

                // Let MongoDB generate ObjectId if client sends empty id
                if (string.IsNullOrWhiteSpace(provider.Id))
                    provider.Id = null;

                var existingProvider = await _providerService.GetByEmailAsync(provider.Email);
                if (existingProvider != null)
                {
                    return BadRequest(new { message = "Email already exists" });
                }

                provider.Password = BCrypt.Net.BCrypt.HashPassword(provider.Password);
                await _providerService.CreateAsync(provider);

                return Ok(new { message = "Service provider registered successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during registration", error = ex.Message });
            }
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            try
            {
                var provider = await _providerService.GetByEmailAsync(loginModel.Email);
                if (provider == null)
                    return Unauthorized(new { message = "Invalid email or password" });

                if (!BCrypt.Net.BCrypt.Verify(loginModel.Password, provider.Password))
                    return Unauthorized(new { message = "Invalid email or password" });

                if (string.IsNullOrWhiteSpace(provider.Id))
                    return StatusCode(500, new { message = "Provider record is missing Id. Please re-register this provider." });

                var token = _providerService.GenerateJwtToken(provider);

                return Ok(new 
                { 
                    message = "Login successful", 
                    token, 
                    providerId = provider.Id,
                    name = provider.Name,
                    email = provider.Email,
                    contact = provider.Contact
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during login", error = ex.Message });
            }
        }

        // Creates a butcher/provider availability slot and stores butcher details
        // (id, name, contact) in the same document (Availability collection).
        [HttpPost("availability")]
        public async Task<IActionResult> CreateAvailabilitySlot([FromBody] CreateProviderAvailabilityDto dto)
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                var provider = await _providerService.GetByIdAsync(providerId);
                if (provider == null)
                    return NotFound(new { message = "Service provider not found" });

                var availability = new Availability
                {
                    ServiceProviderId = providerId,
                    ButcherId = providerId,
                    ButcherName = provider.Name ?? string.Empty,
                    ButcherPhone = provider.Contact ?? string.Empty,

                    AvailableDate = dto.AvailableDate ?? string.Empty,
                    TimeSlot = dto.TimeSlot ?? string.Empty,
                    Location = dto.Location ?? string.Empty,
                    ServiceType = dto.ServiceType ?? string.Empty,
                    PriceRange = dto.PriceRange,
                    SpaceAvailable = dto.SpaceAvailable ?? string.Empty,
                    StartTime = string.IsNullOrWhiteSpace(dto.StartTime) ? "08:00" : dto.StartTime,
                    EndTime = string.IsNullOrWhiteSpace(dto.EndTime) ? "18:00" : dto.EndTime,
                    Days = dto.Days ?? new(),
                    Status = string.IsNullOrWhiteSpace(dto.Status) ? "available" : dto.Status,

                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                await _availabilityService.CreateAsync(availability);
                return Ok(new { message = "Availability added successfully", data = availability });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var providers = await _providerService.GetAllAsync();
            return Ok(providers);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var provider = await _providerService.GetByIdAsync(id);
            if (provider == null)
                return NotFound(new { message = "Service provider not found" });

            return Ok(provider);
        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<IActionResult> GetProfile()
        {
            try
            {
                var providerId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid token" });

                var provider = await _providerService.GetByIdAsync(providerId);
                if (provider == null)
                    return NotFound(new { message = "Profile not found" });

                provider.Password = string.Empty;
                return Ok(provider);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> Update(string id, [FromBody] ServiceProvider provider)
        {
            try
            {
                var currentUserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(currentUserId) || currentUserId != id)
                {
                    return Forbid("You can only update your own profile");
                }

                var existingProvider = await _providerService.GetByIdAsync(id);
                if (existingProvider == null)
                    return NotFound(new { message = "Service provider not found" });

                provider.Id = id;
                if (!string.IsNullOrEmpty(provider.Password))
                {
                    provider.Password = BCrypt.Net.BCrypt.HashPassword(provider.Password);
                }
                else
                {
                    provider.Password = existingProvider.Password;
                }

                await _providerService.UpdateAsync(id, provider);
                return Ok(new { message = "Profile updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var provider = await _providerService.GetByIdAsync(id);
                if (provider == null)
                    return NotFound(new { message = "Service provider not found" });

                await _providerService.DeleteAsync(id);
                return Ok(new { message = "Service provider deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }
    }
}