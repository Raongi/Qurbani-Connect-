using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System;

namespace CattleMarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AvailabilityController : ControllerBase
    {
        private readonly AvailabilityService _availabilityService;
        private readonly ServiceProviderService _providerService;

        public AvailabilityController(AvailabilityService availabilityService, ServiceProviderService providerService)
        {
            _availabilityService = availabilityService;
            _providerService = providerService;
        }

        private string? GetProviderIdFromToken()
        {
            var token = Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);
                return jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            }
            catch
            {
                return null;
            }
        }

        private string? GetProviderEmailFromToken()
        {
            var token = Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);
                return jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value;
            }
            catch
            {
                return null;
            }
        }

      [HttpPost]
public async Task<IActionResult> Create([FromBody] Availability availability)
{
    try
    {
        var providerId = GetProviderIdFromToken();
        if (string.IsNullOrEmpty(providerId))
            return Unauthorized(new { message = "Invalid or missing token" });

        // First try resolving provider by id, fallback to email for older tokens.
        var provider = await _providerService.GetByIdAsync(providerId);
        if (provider == null)
        {
            var email = GetProviderEmailFromToken();
            if (!string.IsNullOrWhiteSpace(email))
                provider = await _providerService.GetByEmailAsync(email);
        }

        if (provider == null || string.IsNullOrWhiteSpace(provider.Id))
            return NotFound(new { message = "Service provider not found" });

        providerId = provider.Id;

        // ✅ Set all required fields
        availability.ServiceProviderId = providerId;
        // Keep these fields populated for UI/display in DB
        availability.ButcherId = providerId;
        availability.ButcherName = provider.Name ?? string.Empty;
        availability.ButcherPhone = provider.Contact ?? string.Empty;
        availability. CreatedAt = DateTime.UtcNow; // Use UTC
        availability.UpdatedAt = DateTime.UtcNow;
        
        // ✅ Ensure status is set
        if (string.IsNullOrEmpty(availability.Status))
            availability.Status = "available";

        await _availabilityService.CreateAsync(availability);
        return Ok(new { message = "Availability added successfully", data = availability });
    }
    catch (Exception ex)
    {
        // ✅ Log the full error
        Console.WriteLine($"ERROR: {ex}");
        return StatusCode(500, new { message = "An error occurred", error = ex.Message, stackTrace = ex.StackTrace });
    }
}

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var availabilities = await _availabilityService.GetAllAsync();
            return Ok(availabilities);
        }

        [HttpGet("available")]
        public async Task<IActionResult> GetAvailable()
        {
            var availabilities = await _availabilityService.GetAvailableSlotsAsync();
            return Ok(availabilities);
        }

        [HttpGet("myprovider")]
        public async Task<IActionResult> GetMyAvailability()
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                // Use resolved provider id for older tokens so the correct slots are returned.
                var provider = await _providerService.GetByIdAsync(providerId);
                if (provider == null)
                {
                    var email = GetProviderEmailFromToken();
                    if (!string.IsNullOrWhiteSpace(email))
                        provider = await _providerService.GetByEmailAsync(email);
                }

                if (provider != null && !string.IsNullOrWhiteSpace(provider.Id))
                    providerId = provider.Id;

                var availabilities = await _availabilityService.GetByProviderIdAsync(providerId);
                return Ok(availabilities);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var availability = await _availabilityService.GetByIdAsync(id);
            if (availability == null)
                return NotFound(new { message = "Availability not found" });

            return Ok(availability);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Availability availability)
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                var provider = await _providerService.GetByIdAsync(providerId);
                if (provider == null)
                {
                    var email = GetProviderEmailFromToken();
                    if (!string.IsNullOrWhiteSpace(email))
                        provider = await _providerService.GetByEmailAsync(email);
                }

                if (provider == null || string.IsNullOrWhiteSpace(provider.Id))
                    return NotFound(new { message = "Service provider not found" });

                providerId = provider.Id;

                var existingAvailability = await _availabilityService.GetByIdAsync(id);
                if (existingAvailability == null)
                    return NotFound(new { message = "Availability not found" });

                if (existingAvailability.ServiceProviderId != providerId)
                    return Forbid();

                availability.Id = id;
                availability.ServiceProviderId = providerId;
                availability.ButcherId = providerId;
                availability.ButcherName = provider.Name ?? string.Empty;
                availability.ButcherPhone = provider.Contact ?? string.Empty;
                availability.UpdatedAt = DateTime.Now;

                await _availabilityService.UpdateAsync(id, availability);
                return Ok(new { message = "Availability updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                var provider = await _providerService.GetByIdAsync(providerId);
                if (provider == null)
                {
                    var email = GetProviderEmailFromToken();
                    if (!string.IsNullOrWhiteSpace(email))
                        provider = await _providerService.GetByEmailAsync(email);
                }

                if (provider != null && !string.IsNullOrWhiteSpace(provider.Id))
                    providerId = provider.Id;

                var availability = await _availabilityService.GetByIdAsync(id);
                if (availability == null)
                    return NotFound(new { message = "Availability not found" });

                if (availability.ServiceProviderId != providerId)
                    return Forbid();

                await _availabilityService.DeleteAsync(id);
                return Ok(new { message = "Availability deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpPatch("{id}/status")]
        public async Task<IActionResult> UpdateStatus(string id, [FromBody] StatusUpdateModel model)
        {
            try
            {
                var availability = await _availabilityService.GetByIdAsync(id);
                if (availability == null)
                    return NotFound(new { message = "Availability not found" });

                await _availabilityService.UpdateStatusAsync(id, model.Status);
                return Ok(new { message = "Status updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }
    }

    public class StatusUpdateModel
    {
        public string Status { get; set; } = string.Empty;
    }
}