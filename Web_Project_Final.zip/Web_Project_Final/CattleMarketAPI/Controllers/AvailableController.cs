using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;

[Route("api/[controller]")]
[ApiController]
public class AvailableController : ControllerBase
{
    private readonly AvailableService _service;

    public AvailableController(AvailableService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string vehiclePlate)
    {
        var data = await _service.GetAsync(vehiclePlate);
        return Ok(data);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Available a)
    {
        await _service.CreateAsync(a);
        return Ok(a);
    }
}
