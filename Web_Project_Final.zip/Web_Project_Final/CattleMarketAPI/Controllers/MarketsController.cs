using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using CattleMarketAPI.Models;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MarketsController : ControllerBase
    {
        private readonly IMongoCollection<Market> _markets;

        public MarketsController(IMongoClient client)
        {
            var database = client.GetDatabase("cattle_market"); // Your DB name
            _markets = database.GetCollection<Market>("sellers"); // Your collection
        }

        [HttpGet]
        public IActionResult GetMarkets()
        {
            try
            {
                var markets = _markets.Find(_ => true).ToList();
                return Ok(markets); // returns JSON
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message }); // returns JSON error
            }
        }
    }
}
