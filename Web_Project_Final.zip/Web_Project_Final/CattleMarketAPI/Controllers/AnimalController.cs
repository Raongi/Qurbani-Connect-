using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Linq;

namespace CattleMarketAPI.Controllers
{[Route("api/[controller]")]
[ApiController]
public class AnimalController : ControllerBase
{
    private readonly AnimalService _animalService;

    public AnimalController(AnimalService animalService)
    {
        _animalService = animalService;
    }

    // GET: api/animal
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _animalService.GetAllAsync());
    }

    // POST: api/animal
    [HttpPost]
public async Task<IActionResult> Create([FromBody] Animal animal)
{
    if (animal.Images != null && animal.Images.Count > 0)
        animal.Images = SaveImages(animal.Images);

    await _animalService.CreateAsync(animal);
    return Ok(new { message = "Animal added successfully" });
}

[HttpPut("{id}")]
public async Task<IActionResult> Update(string id, [FromBody] Animal animal)
{
    var existing = await _animalService.GetByIdAsync(id);
    if (existing == null)
        return NotFound(new { message = "Animal not found" });

    // Check if images are being sent
    if (animal.Images != null && animal.Images.Count > 0)
    {
        // Check if these are base64 images (new uploads) or existing paths
        bool hasBase64Images = animal.Images.Any(img => img.StartsWith("data:image"));
        
        if (hasBase64Images)
        {
            // Save new base64 images
            animal.Images = SaveImages(animal.Images);
        }
        // else: images are already saved paths, keep them as-is
    }
    else
    {
        // No images sent, keep existing images
        animal.Images = existing.Images;
    }

    await _animalService.UpdateAsync(id, animal);
    return Ok(new { message = "Animal updated successfully" });
}
private List<string> SaveImages(List<string> base64Images)
{
    var savedImages = new List<string>();
    var imageFolder = @"C:\Users\RABIA\Desktop\Web_Project_Final\images";

    if (!Directory.Exists(imageFolder))
        Directory.CreateDirectory(imageFolder);

    foreach (var img in base64Images)
    {
        if (!img.StartsWith("data:image")) continue;

        var header = img.Split(',')[0];
        var base64Data = img.Split(',')[1];

        // extract extension
        var ext = header
            .Substring(header.IndexOf("/") + 1)
            .Substring(0, header.IndexOf(";") - header.IndexOf("/") - 1);

        if (ext == "jpeg") ext = "jpg";

        var fileName = $"{Guid.NewGuid()}.{ext}";
        var filePath = Path.Combine(imageFolder, fileName);

        var bytes = Convert.FromBase64String(base64Data);
        System.IO.File.WriteAllBytes(filePath, bytes);

        savedImages.Add($"/images/{fileName}");
    }

    return savedImages;
}

  
[HttpGet("{id}")]
public async Task<IActionResult> GetById(string id)
{
    var animal = await _animalService.GetByIdAsync(id);
    if (animal == null) return NotFound(new { message = "Animal not found" });
    return Ok(animal);
}
[HttpGet("fetch/{id}")]  // note the new route to avoid conflict
public async Task<IActionResult> FetchById(string id)
{
    var animal = await _animalService.FetchAnimalByIdAsync(id);
    if (animal == null) return NotFound(new { message = "Animal not found" });
    return Ok(animal);
}
    // DELETE: api/animal/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id)
    {
        var existing = await _animalService.GetByIdAsync(id);
        if (existing == null) return NotFound();

        await _animalService.DeleteAsync(id);
        return Ok(new { message = "Animal deleted successfully" });
    }
    
    
}


    }
