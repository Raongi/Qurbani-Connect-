using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using System.Threading.Tasks;
using BCrypt.Net;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using System;
using System.IdentityModel.Tokens.Jwt;

namespace CattleMarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SellerController : ControllerBase
    {
        private readonly SellerService _sellerService;
        private readonly IConfiguration _configuration;  // Add IConfiguration

        public SellerController(SellerService sellerService, IConfiguration configuration)
        {
            _sellerService = sellerService;
            _configuration = configuration;  // Initialize IConfiguration
        }

        // Register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Seller seller)
        {
            try
            {
                if (string.IsNullOrEmpty(seller.Email) || string.IsNullOrEmpty(seller.Password))
                {
                    return BadRequest(new { message = "Email and password are required" });
                }

                var existingSeller = await _sellerService.GetByEmailAsync(seller.Email);
                if (existingSeller != null)
                {
                    return BadRequest(new { message = "Email already exists" });
                }

                // Hash the password before saving
                seller.Password = BCrypt.Net.BCrypt.HashPassword(seller.Password);

                // Save the seller to MongoDB
                await _sellerService.CreateAsync(seller);

                return Ok(new { message = "Seller registered successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred during registration", error = ex.Message });
            }
        }
    //login
 [HttpPost("login")]
public async Task<IActionResult> Login(LoginModel loginModel)
{
    var seller = await _sellerService.GetByEmailAsync(loginModel.Email);
    if(seller == null)
        return Unauthorized(new { message = "Invalid email or password" });

    if(!BCrypt.Net.BCrypt.Verify(loginModel.Password, seller.Password))
        return Unauthorized(new { message = "Invalid email or password" });

    var token = GenerateJwtToken(seller);

    // Send sellerId along with token
    return Ok(new { message = "Login successful", token, sellerId = seller.Id });
}
//generate token
      public string GenerateJwtToken(Seller seller)
{
    var claims = new[]
    {
        new Claim(ClaimTypes.Name, seller.FarmerName),
        new Claim(ClaimTypes.Email, seller.Email),
        new Claim(ClaimTypes.NameIdentifier, seller.Id.ToString()) // Include the seller's Id as a claim
    };

    // Make sure to use a strong key with at least 256 bits (32 characters)
    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("YourNewStrongSecretKeyHere1234567890"));
    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

    var token = new JwtSecurityToken(
        issuer: "yourapp.com",
        audience: "yourapp.com",
        claims: claims,
        expires: DateTime.Now.AddHours(1),
        signingCredentials: creds
    );

    return new JwtSecurityTokenHandler().WriteToken(token);
}
// GET: api/seller/latest
[HttpGet("latest")]
public async Task<IActionResult> GetLatestSeller()
{
    var sellers = await _sellerService.GetAllAsync();
    var latest = sellers.OrderByDescending(s => s.CreatedAt).FirstOrDefault();
    if (latest == null) return NotFound();
    return Ok(latest);
}


    }
}
