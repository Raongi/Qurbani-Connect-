using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace CattleMarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly OrderService _orderService;

        public OrderController(OrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var orders = await _orderService.GetAllAsync();
            return Ok(orders);
        }

[HttpPut("status/{id}")]
public async Task<IActionResult> UpdateStatus(string id, [FromBody] Dictionary<string, string> data)
{
    if (!data.ContainsKey("status"))
        return BadRequest(new { message = "Status is required" });

    var order = await _orderService.GetByIdAsync(id);
    if (order == null) return NotFound(new { message = "Order not found" });

    order.Status = data["status"];
    await _orderService.UpdateAsync(id, order);

    return Ok(new { message = "Status updated successfully" });
}


public class StatusUpdateDto
{
    public string Status { get; set; } = "";
}

    }
}
