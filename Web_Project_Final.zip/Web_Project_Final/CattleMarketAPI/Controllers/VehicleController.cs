using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VehicleController : ControllerBase
    {
        private readonly VehicleService _service;

        public VehicleController(VehicleService service)
        {
            _service = service ?? throw new ArgumentNullException(nameof(service));
            Console.WriteLine("✅ VehicleController initialized");
        }

        /// <summary>
        /// GET: api/vehicle - Get all vehicles
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                Console.WriteLine("🌐 [GET] /api/vehicle - Fetching all vehicles");
                var vehicles = await _service.GetAsync();
                Console.WriteLine($"✅ Returning {vehicles.Count} vehicles");
                return Ok(vehicles);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ [GET] /api/vehicle - Error: {ex.Message}");
                return StatusCode(500, new { 
                    error = "Failed to fetch vehicles", 
                    details = ex.Message 
                });
            }
        }

        /// <summary>
        /// GET: api/vehicle/{id} - Get vehicle by ID
        /// </summary>
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            try
            {
                Console.WriteLine($"🌐 [GET] /api/vehicle/{id}");
                
                if (string.IsNullOrWhiteSpace(id))
                    return BadRequest(new { error = "Vehicle ID is required" });

                var vehicle = await _service.GetByIdAsync(id);
                
                if (vehicle == null)
                {
                    Console.WriteLine($"⚠️ Vehicle not found: {id}");
                    return NotFound(new { error = "Vehicle not found" });
                }

                Console.WriteLine($"✅ Vehicle found: {vehicle.MakeModel}");
                return Ok(vehicle);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ [GET] /api/vehicle/{id} - Error: {ex.Message}");
                return StatusCode(500, new { 
                    error = "Failed to fetch vehicle", 
                    details = ex.Message 
                });
            }
        }

        /// <summary>
        /// POST: api/vehicle - Create new vehicle
        /// </summary>
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Vehicle vehicle)
        {
            try
            {
                Console.WriteLine("🌐 [POST] /api/vehicle - Creating new vehicle");
                
                // Null check
                if (vehicle == null)
                {
                    Console.WriteLine("❌ Vehicle data is null");
                    return BadRequest(new { error = "Vehicle data is required" });
                }

                Console.WriteLine($"📝 Received: {vehicle.MakeModel} ({vehicle.LicensePlate})");

                // Manual validation
                var validationErrors = new List<string>();

                if (string.IsNullOrWhiteSpace(vehicle.VehicleType))
                    validationErrors.Add("VehicleType is required");

                if (string.IsNullOrWhiteSpace(vehicle.MakeModel))
                    validationErrors.Add("MakeModel is required");

                if (string.IsNullOrWhiteSpace(vehicle.LicensePlate))
                    validationErrors.Add("LicensePlate is required");

                if (string.IsNullOrWhiteSpace(vehicle.TransporterEmail))
                    validationErrors.Add("TransporterEmail is required");

                if (vehicle.Year < 1990 || vehicle.Year > 2030)
                    validationErrors.Add("Year must be between 1990 and 2030");

                if (vehicle.Capacity < 0)
                    validationErrors.Add("Capacity must be positive");

                if (validationErrors.Count > 0)
                {
                    Console.WriteLine($"❌ Validation failed: {string.Join(", ", validationErrors)}");
                    return BadRequest(new { 
                        error = "Validation failed", 
                        details = validationErrors 
                    });
                }

                // Set defaults
                if (vehicle.Images == null)
                    vehicle.Images = new List<string>();

                if (string.IsNullOrWhiteSpace(vehicle.Status))
                    vehicle.Status = "Active";

                vehicle.CreatedAt = DateTime.Now;
                vehicle.UpdatedAt = DateTime.Now;

                // Create in database
                var created = await _service.CreateAsync(vehicle);
                
                Console.WriteLine($"✅ Vehicle created successfully: ID = {created.Id}");
                return Ok(created);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ [POST] /api/vehicle - Error: {ex.Message}");
                Console.WriteLine($"   Stack Trace: {ex.StackTrace}");
                return StatusCode(500, new { 
                    error = "Failed to create vehicle", 
                    details = ex.Message,
                    stackTrace = ex.StackTrace
                });
            }
        }

        /// <summary>
        /// PUT: api/vehicle/{id} - Update existing vehicle
        /// </summary>
        [HttpPut("{id}")]
public async Task<IActionResult> Update(string id, [FromBody] Vehicle vehicle)
{
    try
    {
        if (string.IsNullOrWhiteSpace(id))
            return BadRequest(new { error = "Vehicle ID is required" });

        if (vehicle == null)
            return BadRequest(new { error = "Vehicle data is required" });

        var existing = await _service.GetByIdAsync(id);
        if (existing == null)
            return NotFound(new { error = "Vehicle not found" });

        // 🔒 PRESERVE DATA
        vehicle.Id = id;
        vehicle.CreatedAt = existing.CreatedAt;
        vehicle.UpdatedAt = DateTime.Now;

        // 🔒 PRESERVE IMAGES
        if (vehicle.Images == null || vehicle.Images.Count == 0)
        {
            vehicle.Images = existing.Images;
        }

        await _service.UpdateAsync(id, vehicle);
        return Ok(vehicle);
    }
    catch (Exception ex)
    {
        return StatusCode(500, new
        {
            error = "Failed to update vehicle",
            details = ex.Message
        });
    }
}

        /// <summary>
        /// DELETE: api/vehicle/{id} - Delete vehicle
        /// </summary>
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                Console.WriteLine($"🌐 [DELETE] /api/vehicle/{id}");
                
                if (string.IsNullOrWhiteSpace(id))
                    return BadRequest(new { error = "Vehicle ID is required" });

                // Check if exists
                var existing = await _service.GetByIdAsync(id);
                if (existing == null)
                {
                    Console.WriteLine($"⚠️ Vehicle not found: {id}");
                    return NotFound(new { error = "Vehicle not found" });
                }

                // Delete
                await _service.DeleteAsync(id);
                
                Console.WriteLine($"✅ Vehicle deleted: {existing.MakeModel}");
                return Ok(new { 
                    message = "Vehicle deleted successfully",
                    deletedVehicle = existing.MakeModel
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ [DELETE] /api/vehicle/{id} - Error: {ex.Message}");
                return StatusCode(500, new { 
                    error = "Failed to delete vehicle", 
                    details = ex.Message 
                });
            }
        }
    }
}