using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using System.Threading.Tasks;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Linq;
using System;

namespace CattleMarketAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;
        private readonly AvailabilityService _availabilityService;

        public BookingController(BookingService bookingService, AvailabilityService availabilityService)
        {
            _bookingService = bookingService;
            _availabilityService = availabilityService;
        }

        private string? GetProviderIdFromToken()
        {
            var authHeader = Request.Headers["Authorization"].ToString();
            if (string.IsNullOrWhiteSpace(authHeader))
                return null;

            var token = authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)
                ? authHeader.Substring("Bearer ".Length)
                : authHeader;
            token = token.Trim();
            if (string.IsNullOrEmpty(token))
                return null;

            try
            {
                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadJwtToken(token);
                return jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;
            }
            catch
            {
                return null;
            }
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Booking booking)
        {
            try
            {
                var availability = await _availabilityService.GetByIdAsync(booking.AvailabilityId);
                if (availability == null)
                    return NotFound(new { message = "Availability not found" });

                if (availability.Status != "available")
                    return BadRequest(new { message = "This slot is no longer available" });

                booking.ServiceProviderId = availability.ServiceProviderId;
                booking.CreatedAt = DateTime.Now;
                booking.UpdatedAt = DateTime.Now;

                await _bookingService.CreateAsync(booking);
                await _availabilityService.UpdateStatusAsync(booking.AvailabilityId, "booked");

                return Ok(new { message = "Booking created successfully", data = booking });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var bookings = await _bookingService.GetAllAsync();
            return Ok(bookings);
        }

        [HttpGet("myprovider")]
        public async Task<IActionResult> GetMyBookings()
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                var bookings = await _bookingService.GetByProviderIdAsync(providerId);
                return Ok(bookings);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var booking = await _bookingService.GetByIdAsync(id);
            if (booking == null)
                return NotFound(new { message = "Booking not found" });

            return Ok(booking);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, [FromBody] Booking booking)
        {
            try
            {
                var existingBooking = await _bookingService.GetByIdAsync(id);
                if (existingBooking == null)
                    return NotFound(new { message = "Booking not found" });

                booking.Id = id;
                booking.UpdatedAt = DateTime.Now;

                await _bookingService.UpdateAsync(id, booking);
                return Ok(new { message = "Booking updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpPatch("{id}/status")]
        public async Task<IActionResult> UpdateStatus(string id, [FromBody] BookingStatusUpdateModel model)
        {
            try
            {
                var providerId = GetProviderIdFromToken();
                if (string.IsNullOrEmpty(providerId))
                    return Unauthorized(new { message = "Invalid or missing token" });

                var booking = await _bookingService.GetByIdAsync(id);
                if (booking == null)
                    return NotFound(new { message = "Booking not found" });

                if (booking.ServiceProviderId != providerId)
                    return Forbid();

                await _bookingService.UpdateStatusAsync(id, model.Status);

                if (model.Status == "cancelled")
                {
                    await _availabilityService.UpdateStatusAsync(booking.AvailabilityId, "available");
                }

                return Ok(new { message = "Booking status updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                var booking = await _bookingService.GetByIdAsync(id);
                if (booking == null)
                    return NotFound(new { message = "Booking not found" });

                await _availabilityService.UpdateStatusAsync(booking.AvailabilityId, "available");
                await _bookingService.DeleteAsync(id);
                return Ok(new { message = "Booking deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred", error = ex.Message });
            }
        }
    }

    public class BookingStatusUpdateModel
    {
        public string Status { get; set; } = string.Empty;
    }
}