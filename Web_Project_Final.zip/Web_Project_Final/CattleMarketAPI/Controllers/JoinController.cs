using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using System.Security.Claims;
using CattleMarketAPI.Models;
using CattleMarketAPI.DTOs;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/join")]
    public class JoinController : ControllerBase
    {
        private readonly IMongoCollection<Join> _join;
        private readonly IMongoCollection<Available> _available;

        public JoinController(IMongoClient client)
        {
            var db = client.GetDatabase("cattle_market");
            _join = db.GetCollection<Join>("Join");
            _available = db.GetCollection<Available>("Available");
        }

[Authorize]
[HttpPost]
public async Task<IActionResult> JoinAvailability([FromBody] JoinDto dto)
{
    try
    {
        var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        if (string.IsNullOrEmpty(userId))
            return Unauthorized(new { message = "Invalid user token" });

        // ✅ FIX: define these (were missing)
        var userName = User.FindFirst(ClaimTypes.Name)?.Value ?? "N/A";
        var userEmail = User.FindFirst(ClaimTypes.Email)?.Value ?? "N/A";

        var availability = await _available
            .Find(a => a.Id == dto.AvailabilityId)
            .FirstOrDefaultAsync();

        if (availability == null)
            return NotFound(new { message = "Availability not found" });

        if (availability.AvailableSpace <= 0)
            return BadRequest(new { message = "No space left" });

        // ✅ FIX: only ONE insert (with extra fields)
        await _join.InsertOneAsync(new Join
        {
            AvailabilityId = dto.AvailabilityId,
            UserId = userId,
            UserName = userName,
            UserContact = userEmail,
            VehiclePlate = availability.VehiclePlate,
            JoinedAt = DateTime.UtcNow
        });

        // update AvailableSpace
        availability.AvailableSpace--;
        if (availability.AvailableSpace == 0)
            availability.Status = "Full";

        await _available.ReplaceOneAsync(a => a.Id == availability.Id, availability);

        return Ok(new { message = "Joined successfully" });
    }
    catch (Exception ex)
    {
        return StatusCode(500, new { message = "Server error", error = ex.Message });
    }
}
[HttpGet("by-availability/{availabilityId}")]
public async Task<IActionResult> GetByAvailability(string availabilityId)
{
    var joins = await _join.Find(j => j.AvailabilityId == availabilityId).ToListAsync();
    return Ok(joins);
}
[HttpGet]
public async Task<IActionResult> GetAllJoins()
{
    var joins = await _join.Find(_ => true)
        .SortByDescending(j => j.JoinedAt)
        .ToListAsync();

    return Ok(joins);
}
    }
}
