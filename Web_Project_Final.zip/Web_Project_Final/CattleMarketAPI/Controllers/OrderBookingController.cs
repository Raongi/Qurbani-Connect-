using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using CattleMarketAPI.Services;
using System;
using System.Collections.Generic;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderBookingController : ControllerBase
    {
        private readonly OrderBookingService _orderBookingService;

        public OrderBookingController(OrderBookingService orderBookingService)
        {
            _orderBookingService = orderBookingService;
        }

        // GET: api/orderbooking
        [HttpGet]
        public ActionResult<List<OrderBooking>> GetAllOrderBookings()
        {
            try
            {
                var orders = _orderBookingService.GetAllOrderBookings();
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/orderbooking/{id}
        [HttpGet("{id}")]
        public ActionResult<OrderBooking> GetOrderBookingById(string id)
        {
            try
            {
                var order = _orderBookingService.GetOrderBookingById(id);
                if (order == null)
                    return NotFound(new { message = "Order not found" });

                return Ok(order);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // POST: api/orderbooking
// POST: api/orderbooking
 [HttpPost]
        public ActionResult<OrderBooking> CreateOrderBooking([FromBody] OrderBooking orderBooking)
        {
            try
            {
                if (orderBooking == null)
                    return BadRequest(new { message = "Invalid order data" });

                // ✅ CRITICAL: Clear Id before inserting
                orderBooking.Id = null;

                // Set OrderDate if not provided
                if (orderBooking.OrderDate == default(DateTime))
                {
                    orderBooking.OrderDate = DateTime.Now;
                }

                // Calculate total price if not provided
                if (orderBooking.TotalPrice == 0 && orderBooking.PricePerUnit > 0)
                {
                    orderBooking.TotalPrice = orderBooking.PricePerUnit * orderBooking.Quantity;
                }

                // Set default status
                if (string.IsNullOrEmpty(orderBooking.Status))
                {
                    orderBooking.Status = "Pending";
                }

                var createdOrder = _orderBookingService.CreateOrderBooking(orderBooking);
                
                return CreatedAtAction(
                    nameof(GetOrderBookingById), 
                    new { id = createdOrder.Id }, 
                    createdOrder
                );
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // PUT: api/orderbooking/{id}
        [HttpPut("{id}")]
        public ActionResult UpdateOrderBooking(string id, [FromBody] OrderBooking orderBooking)
        {
            try
            {
                var updated = _orderBookingService.UpdateOrderBooking(id, orderBooking);
                
                if (!updated)
                    return NotFound(new { message = "Order not found" });

                return Ok(new { message = "Order updated successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // PATCH: api/orderbooking/{id}/status
        [HttpPatch("{id}/status")]
        public ActionResult UpdateOrderStatus(string id, [FromBody] StatusUpdate statusUpdate)
        {
            try
            {
                var updated = _orderBookingService.UpdateOrderStatus(id, statusUpdate.Status);
                
                if (!updated)
                    return NotFound(new { message = "Order not found" });

                return Ok(new { message = "Status updated successfully", status = statusUpdate.Status });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // DELETE: api/orderbooking/{id}
        [HttpDelete("{id}")]
        public ActionResult DeleteOrderBooking(string id)
        {
            try
            {
                var deleted = _orderBookingService.DeleteOrderBooking(id);
                
                if (!deleted)
                    return NotFound(new { message = "Order not found" });

                return Ok(new { message = "Order deleted successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/orderbooking/customer/{email}
        [HttpGet("customer/{email}")]
        public ActionResult<List<OrderBooking>> GetOrderBookingsByCustomer(string email)
        {
            try
            {
                var orders = _orderBookingService.GetOrderBookingsByCustomer(email);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // GET: api/orderbooking/status/{status}
        [HttpGet("status/{status}")]
        public ActionResult<List<OrderBooking>> GetOrderBookingsByStatus(string status)
        {
            try
            {
                var orders = _orderBookingService.GetOrderBookingsByStatus(status);
                return Ok(orders);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }

    // Helper class for status update
    public class StatusUpdate
    {
        public string Status { get; set; }
    }
}