using Microsoft.AspNetCore.Mvc;
using CattleMarketAPI.Models;
using System.Threading.Tasks;
using BCrypt.Net;
using System;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.IdentityModel.Tokens.Jwt;

namespace CattleMarketAPI.Controllers
{
    [ApiController]
    [Route("api/Transport")]
    public class TransportController : ControllerBase
    {
        private readonly TransportService _transportService;

        public TransportController(TransportService transportService)
        {
            _transportService = transportService;
        }

        // REGISTER
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Transport transporter)
        {
            if (string.IsNullOrWhiteSpace(transporter.Email) ||
                string.IsNullOrWhiteSpace(transporter.Password))
            {
                return BadRequest(new { message = "Email and password are required" });
            }

            var existing = await _transportService.GetByEmailAsync(transporter.Email);
            if (existing != null)
                return BadRequest(new { message = "Email already exists" });

            transporter.Password = BCrypt.Net.BCrypt.HashPassword(transporter.Password);

            await _transportService.CreateAsync(transporter);

            return Ok(new { message = "Transporter registered successfully" });
        }

        // LOGIN
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel loginModel)
        {
            var transporter = await _transportService.GetByEmailAsync(loginModel.Email);
            if (transporter == null ||
                !BCrypt.Net.BCrypt.Verify(loginModel.Password, transporter.Password))
            {
                return Unauthorized(new { message = "Invalid email or password" });
            }

            var token = GenerateJwtToken(transporter);

            return Ok(new
            {
                token,
                transporterId = transporter.Id
            });
        }

        // JWT
        private string GenerateJwtToken(Transport transporter)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Name, transporter.TransporterName),
                new Claim(ClaimTypes.Email, transporter.Email),
                new Claim(ClaimTypes.NameIdentifier, transporter.Id)
            };

            var key = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes("YourNewStrongSecretKeyHere1234567890")
            );

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    [HttpGet("latest")]
        public async Task<IActionResult> GetLatestTransporter()
        {
            var transporters = await _transportService.GetAllAsync();

            var latest = transporters
                .OrderByDescending(t => t.CreatedAt)
                .FirstOrDefault();

            if (latest == null) return NotFound();
            return Ok(latest);
        }
    }
}
