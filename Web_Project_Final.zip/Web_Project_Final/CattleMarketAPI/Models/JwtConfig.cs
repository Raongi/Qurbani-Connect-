namespace CattleMarketAPI.Models
{
    public class JwtConfig
    {
        public string SecretKey { get; set; } // Secret Key for JWT
    }
}