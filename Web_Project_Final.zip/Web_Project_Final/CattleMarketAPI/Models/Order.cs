using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace CattleMarketAPI.Models
{
    public class Order
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string AnimalId { get; set; }  // Animal reference

        public string CustomerName { get; set; } = "";
        public int Quantity { get; set; }
        public double TotalPrice { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public string Status { get; set; } = "Pending"; // Pending/Completed
    }
}
