using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    public class Join
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string AvailabilityId { get; set; }
        public string UserId { get; set; }
         // ✅ NEW: snapshot fields
        public string UserName { get; set; }
        public string UserContact { get; set; }   // email or phone
        public string VehiclePlate { get; set; }

        public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
    }
}
