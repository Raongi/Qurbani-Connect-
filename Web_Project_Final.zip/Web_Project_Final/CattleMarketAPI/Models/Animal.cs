using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    public class Animal
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [BsonIgnoreIfDefault]   // ✅ FIX: Id is NOT required from client
        public string? Id { get; set; }

        public string Type { get; set; } = null!;
        public string Breed { get; set; } = null!;
        public int Age { get; set; }
        public double Weight { get; set; }
        public double Price { get; set; }
        public string Gender { get; set; } = null!;
        public string Description { get; set; } = "";
        public string Status { get; set; } = "available"; // ✅ DEFAULT VALUE
        // ✅ New property for images
    public List<string> Images { get; set; } = new List<string>();
     // ✅ NEW (seller info)
        public string SellerPhone { get; set; } = "";
        public string SellerEmail { get; set; } = "";
    }
}
