using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    public class Butcher
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        public string City { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Link { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}
