using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace CattleMarketAPI.Models
{
    public class AnimalDto
    {
        [Required] public string Type { get; set; } = null!;
        [Required] public string Breed { get; set; } = null!;
        [Required] public int Age { get; set; }
        [Required] public double Weight { get; set; }
        [Required] public double Price { get; set; }
        [Required] public string Gender { get; set; } = null!;
        [Required] public string Status { get; set; } = "Available";
        [Required] public string Description { get; set; } = null!;
        [Required] public IFormFile Image { get; set; } = null!;
        public string? ImageUrl { get; set; }
    }
}
