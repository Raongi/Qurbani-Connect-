using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    public class Available
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string VehiclePlate { get; set; }
        public string Date { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public int AvailableSpace { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
    }
}
