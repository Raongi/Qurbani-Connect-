using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Market
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string City { get; set; }

        [BsonElement("FarmerName")]
        public string CattleName { get; set; }  // maps FarmerName to CattleName

        public string Address { get; set; }
        public string Phone { get; set; }
        public string GoogleMapLink { get; set; }
    }
}
