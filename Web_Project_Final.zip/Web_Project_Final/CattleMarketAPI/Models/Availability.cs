using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Availability
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("butcherId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? ButcherId { get; set; }
        public string ServiceProviderId { get; set; } = string.Empty;

        [BsonElement("butcherName")]
        public string ButcherName { get; set; } = string.Empty;

        [BsonElement("butcherPhone")]
        public string ButcherPhone { get; set; } = string.Empty;

        [BsonElement("days")]
        public List<string> Days { get; set; } = new();

        // Fields used by the Service Provider (butcher) UI
        [BsonElement("availableDate")]
        public string AvailableDate { get; set; } = string.Empty;

        [BsonElement("timeSlot")]
        public string TimeSlot { get; set; } = string.Empty;

        [BsonElement("location")]
        public string Location { get; set; } = string.Empty;

        [BsonElement("serviceType")]
        public string ServiceType { get; set; } = string.Empty;

        [BsonElement("priceRange")]
        public double PriceRange { get; set; }

        [BsonElement("spaceAvailable")]
        public string SpaceAvailable { get; set; } = string.Empty;

        [BsonElement("startTime")]
        public string StartTime { get; set; } = "08:00";

        [BsonElement("endTime")]
        public string EndTime { get; set; } = "18:00";

        [BsonElement("status")]
        public string Status { get; set; } = "available";

        [BsonElement("createdAt")]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        [BsonElement("updatedAt")]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}