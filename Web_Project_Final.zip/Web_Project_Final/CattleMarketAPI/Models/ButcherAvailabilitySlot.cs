using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    public class ButcherAvailabilitySlot
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonRepresentation(BsonType.ObjectId)]
        public string ButcherId { get; set; }

        public string ButcherName { get; set; }

        // yyyy-MM-dd
        public string Date { get; set; }

        // HH:mm
        public string StartTime { get; set; }
        public string EndTime { get; set; }

        public string City { get; set; }
        public string Location { get; set; }

        // Available / Booked
        public string Status { get; set; } = "Available";
    }
}