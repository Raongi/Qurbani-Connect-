using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace CattleMarketAPI.Models
{
    public class Booking
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = string.Empty;

        public string AvailabilityId { get; set; } = string.Empty;
        
        public string ServiceProviderId { get; set; } = string.Empty;
        
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerEmail { get; set; } = string.Empty;
        public string CustomerContact { get; set; } = string.Empty;
        public string CustomerAddress { get; set; } = string.Empty;
        
        public DateTime BookingDate { get; set; }
        public string TimeSlot { get; set; } = string.Empty;
        public string ServiceType { get; set; } = string.Empty;
        public string Status { get; set; } = "pending";
        public decimal Price { get; set; }
        public string SpecialRequirements { get; set; } = string.Empty;
        
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
    }
}