using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CattleMarketAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Vehicle
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        [Required(ErrorMessage = "Vehicle type is required")]
        [BsonElement("vehicleType")]
        public string VehicleType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Make/Model is required")]
        [BsonElement("makeModel")]
        public string MakeModel { get; set; } = string.Empty;

        [Required(ErrorMessage = "License plate is required")]
        [BsonElement("licensePlate")]
        public string LicensePlate { get; set; } = string.Empty;

        [Range(1990, 2030, ErrorMessage = "Year must be between 1990 and 2030")]
        [BsonElement("year")]
        public int Year { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Capacity must be positive")]
        [BsonElement("capacity")]
        public int Capacity { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Length must be positive")]
        [BsonElement("length")]
        public double Length { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Width must be positive")]
        [BsonElement("width")]
        public double Width { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "Height must be positive")]
        [BsonElement("height")]
        public double Height { get; set; }

        [Required(ErrorMessage = "Fuel type is required")]
        [BsonElement("fuelType")]
        public string FuelType { get; set; } = string.Empty;

        [Required(ErrorMessage = "Transporter email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        [BsonElement("transporterEmail")]
        public string TransporterEmail { get; set; } = string.Empty;

        [BsonElement("images")]
        public List<string> Images { get; set; } = new();

        [BsonElement("status")]
        public string Status { get; set; } = "Active";

        [BsonElement("createdAt")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public System.DateTime CreatedAt { get; set; } = System.DateTime.Now;

        [BsonElement("updatedAt")]
        [BsonDateTimeOptions(Kind = DateTimeKind.Local)]
        public System.DateTime UpdatedAt { get; set; } = System.DateTime.Now;
    }
}