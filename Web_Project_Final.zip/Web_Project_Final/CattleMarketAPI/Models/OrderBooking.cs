using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.ComponentModel.DataAnnotations;  // ← Import this

namespace CattleMarketAPI.Models
{
    public class OrderBooking
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("animalId")]
        public string AnimalId { get; set; }

        [BsonElement("customerName")]
        public string CustomerName { get; set; }

        [BsonElement("customerEmail")]
        public string CustomerEmail { get; set; }

        [BsonElement("customerPhone")]
        public string CustomerPhone { get; set; }

        [BsonElement("animalType")]
        public string AnimalType { get; set; }

        [BsonElement("animalBreed")]
        public string AnimalBreed { get; set; }

        [BsonElement("animalAge")]
        public string AnimalAge { get; set; }

        [BsonElement("animalWeight")]
        public string AnimalWeight { get; set; }

        [BsonElement("animalGender")]
        public string AnimalGender { get; set; }

        [BsonElement("quantity")]
        public int Quantity { get; set; } = 1;

        [BsonElement("pricePerUnit")]
        public decimal PricePerUnit { get; set; }

        [BsonElement("totalPrice")]
        public decimal TotalPrice { get; set; }

        [BsonElement("bookingDate")]
        public string BookingDate { get; set; }

        [BsonElement("bookingTime")]
        public string BookingTime { get; set; }

        [BsonElement("transport")]
        public string Transport { get; set; }

        [BsonElement("specialInstructions")]
        public string SpecialInstructions { get; set; }

        [BsonElement("orderDate")]
        public DateTime OrderDate { get; set; } = DateTime.Now;

        [BsonElement("status")]
        public string Status { get; set; } = "Pending";

        [BsonElement("sellerEmail")]
        public string SellerEmail { get; set; }

        [BsonElement("sellerPhone")]
        public string SellerPhone { get; set; }
    }
}