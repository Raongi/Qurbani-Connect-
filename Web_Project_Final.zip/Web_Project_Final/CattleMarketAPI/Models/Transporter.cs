using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CattleMarketAPI.Models
{
    [BsonIgnoreExtraElements]
    public class Transporter
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = null!;

        public string City { get; set; } = string.Empty;

        [BsonElement("FarmerName")]
        public string TransporterName { get; set; } = string.Empty; // Map FarmerName → TransporterName

        public string Address { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        public string Link { get; set; } = string.Empty; // Google Map link
    }
}
