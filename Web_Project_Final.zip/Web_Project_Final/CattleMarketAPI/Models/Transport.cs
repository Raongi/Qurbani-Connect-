using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace CattleMarketAPI.Models
{
    public class Transport
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        public string TransporterName { get; set; }
        public string CompanyName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Password { get; set; }
        public string TransportType { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string LicenseNumber { get; set; }
        public int Experience { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
