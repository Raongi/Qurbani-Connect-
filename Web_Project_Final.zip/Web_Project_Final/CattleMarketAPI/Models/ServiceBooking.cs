using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace CattleMarketAPI.Models
{
    public class ServiceBooking
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        // User info (from token claims)
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string UserContact { get; set; }   // email/phone

        // Butcher info
        [BsonRepresentation(BsonType.ObjectId)]
        public string ButcherId { get; set; }
        public string ButcherName { get; set; }

        // Slot reference
        public string AvailabilityId { get; set; }

        // Slot snapshot
        public string Date { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public string Location { get; set; }

        public string Status { get; set; } = "Pending";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}