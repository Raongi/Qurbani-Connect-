// ==========================
// GLOBAL CONFIG
// ==========================
const API_BASE = 'http://localhost:5000/api';
const TOKEN_KEY = 'butcherToken';

// ==========================
// AUTH CHECK (ALL PAGES)
// ==========================
$(document).ready(function () {
    const currentPage = window.location.pathname.split('/').pop();
    const token = localStorage.getItem(TOKEN_KEY);

    if (currentPage !== 'login.html' && currentPage !== 'register.html') {
        if (!token) {
            window.location.href = 'login.html';
            return;
        }
        $('#butcherName').text(localStorage.getItem('butcherName') || 'Butcher');
    }

    if (currentPage === 'index.html') loadButcherDashboard();
    if (currentPage === 'bookings.html') loadAllBookings();
    if (currentPage === 'profile.html') loadButcherProfile();
});

// ==========================
// DASHBOARD
// ==========================
function loadButcherDashboard() {
    const token = localStorage.getItem(TOKEN_KEY);

    $.ajax({
        url: `${API_BASE}/butcher/stats`,
        headers: { Authorization: `Bearer ${token}` },
        success: res => {
            const d = res.data || {};
            $('.stat-card:eq(0) h3').text(d.totalBookings || 0);
            $('.stat-card:eq(1) h3').text(d.pendingBookings || 0);
            $('.stat-card:eq(2) h3').text(d.completedBookings || 0);
            $('.stat-card:eq(3) h3').text((d.rating || 0).toFixed(1));
        },
        error: err => console.error('Stats error', err)
    });

    loadRecentBookings();
}

function loadRecentBookings() {
    const token = localStorage.getItem(TOKEN_KEY);

    $.ajax({
        url: `${API_BASE}/butcher/bookings?status=all`,
        headers: { Authorization: `Bearer ${token}` },
        success: res => displayRecentBookings(res.data),
        error: err => console.error('Recent bookings error', err)
    });
}

function displayRecentBookings(bookings = []) {
    const tbody = $('.data-table tbody');
    tbody.empty();

    if (!bookings.length) {
        tbody.html(`<tr><td colspan="7" class="text-center">No recent bookings</td></tr>`);
        return;
    }

    bookings.slice(0, 5).forEach(b => {
        tbody.append(`
            <tr>
                <td>${b.bookingId || b._id}</td>
                <td>${b.customerName || 'N/A'}</td>
                <td>${formatDate(b.bookingDate)}</td>
                <td>${b.bookingTime || 'N/A'}</td>
                <td>${b.animal?.type || 'N/A'}</td>
                <td>${b.location?.address || 'N/A'}</td>
                <td>${getStatusBadge(b.status || 'pending')}</td>
            </tr>
        `);
    });
}

// ==========================
// BOOKINGS
// ==========================
let allBookingsData = [];

function loadAllBookings() {
    const token = localStorage.getItem(TOKEN_KEY);

    $.ajax({
        url: `${API_BASE}/butcher/bookings`,
        headers: { Authorization: `Bearer ${token}` },
        success: res => {
            allBookingsData = res.data || [];
            updateBookingsTable(allBookingsData);
            updateBookingsStats(allBookingsData);
        },
        error: err => {
            console.error(err);
            $('#bookingsTable').html(
                `<tr><td colspan="10" class="text-center text-danger">Failed to load bookings</td></tr>`
            );
        }
    });
}

function updateBookingsStats(bookings) {
    $('#totalBookings').text(bookings.length);
    $('#pendingBookings').text(bookings.filter(b => b.status === 'pending').length);
    $('#confirmedBookings').text(bookings.filter(b => b.status === 'confirmed').length);
    $('#completedBookings').text(bookings.filter(b => b.status === 'completed').length);
}

function filterBookings(status, event) {
    $('.btn-group .btn').removeClass('active');
    if (event?.target) event.target.classList.add('active');

    const filtered =
        status === 'all'
            ? allBookingsData
            : allBookingsData.filter(b => b.status === status);

    updateBookingsTable(filtered);
}

function updateBookingsTable(bookings = []) {
    const tbody = $('#bookingsTable');
    tbody.empty();

    if (!bookings.length) {
        tbody.html(`<tr><td colspan="10" class="text-center">No bookings found</td></tr>`);
        return;
    }

    bookings.forEach(b => {
        const id = b._id || b.id;

        tbody.append(`
            <tr>
                <td>${b.bookingId || id}</td>
                <td>${b.customerName || 'N/A'}</td>
                <td>${b.customerPhone || 'N/A'}</td>
                <td>${formatDate(b.bookingDate)}</td>
                <td>${b.bookingTime || 'N/A'}</td>
                <td>${b.animal?.type || 'N/A'}</td>
                <td>${b.location?.address || 'N/A'}</td>
                <td>Rs. ${b.totalAmount || 0}</td>
                <td>${getStatusBadge(b.status)}</td>
                <td>
                    ${b.status === 'pending' ? `
                        <button class="btn btn-success btn-sm" onclick="acceptBooking('${id}')">Accept</button>
                        <button class="btn btn-danger btn-sm" onclick="rejectBooking('${id}')">Reject</button>
                    ` : ''}
                    ${b.status === 'confirmed' ? `
                        <button class="btn btn-primary btn-sm" onclick="completeBooking('${id}')">Complete</button>
                    ` : ''}
                </td>
            </tr>
        `);
    });
}

// ==========================
// BOOKING ACTIONS
// ==========================
function bookingAction(endpoint) {
    const token = localStorage.getItem(TOKEN_KEY);

    $.ajax({
        url: `${API_BASE}${endpoint}`,
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` },
        success: () => loadAllBookings(),
        error: err => console.error('Booking action error', err)
    });
}

function acceptBooking(id) {
    if (confirm('Accept this booking?')) {
        bookingAction(`/butcher/bookings/${id}/accept`);
    }
}

function rejectBooking(id) {
    if (confirm('Reject this booking?')) {
        bookingAction(`/butcher/bookings/${id}/reject`);
    }
}

function completeBooking(id) {
    if (confirm('Mark this booking as completed?')) {
        bookingAction(`/butcher/bookings/${id}/complete`);
    }
}

// ==========================
// PROFILE
// ==========================
function loadButcherProfile() {
    const token = localStorage.getItem(TOKEN_KEY);

    $.ajax({
        url: `${API_BASE}/butcher/profile`,
        headers: { Authorization: `Bearer ${token}` },
        success: res => populateProfileForm(res),
        error: err => console.error('Profile load error', err)
    });
}

function populateProfileForm(b) {
    $('#butcherName').text(b.name || 'Butcher');

    $('input[name="name"]').val(b.name || '');
    $('input[name="cnic"]').val(b.cnic || '');
    $('input[name="email"]').val(b.email || '');
    $('input[name="phone"]').val(b.phone || '');
    $('textarea[name="address"]').val(b.address || '');
    $('select[name="type"]').val(b.type || 'typeA');
    $('input[name="experience"]').val(b.experience || 0);
    $('input[name="rate"]').val(b.rate || 0);
    $('textarea[name="about"]').val(b.about || '');

    $('.profile-info p:first').html(
        `<i class="fas fa-star text-warning"></i> Rating: ${(b.rating || 0).toFixed(1)}/5.0`
    );
}

$('#profileForm').on('submit', function (e) {
    e.preventDefault();

    const token = localStorage.getItem(TOKEN_KEY);

    const data = {
        name: $('input[name="name"]').val(),
        email: $('input[name="email"]').val(),
        phone: $('input[name="phone"]').val(),
        address: $('textarea[name="address"]').val(),
        type: $('select[name="type"]').val(),
        experience: +$('input[name="experience"]').val(),
        rate: +$('input[name="rate"]').val(),
        about: $('textarea[name="about"]').val()
    };

    $.ajax({
        url: `${API_BASE}/butcher/profile`,
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` },
        contentType: 'application/json',
        data: JSON.stringify(data),
        success: () => alert('Profile updated successfully'),
        error: err => console.error('Profile update error', err)
    });
});

// ==========================
// HELPERS
// ==========================
function getStatusBadge(status = 'pending') {
    return `<span class="badge badge-${status}">${status}</span>`;
}

function formatDate(date) {
    return date ? new Date(date).toLocaleDateString() : 'N/A';
}

// ==========================
// LOGOUT
// ==========================
function logout() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem('butcherName');
    localStorage.removeItem('butcherId');
    window.location.href = 'login.html';
}
