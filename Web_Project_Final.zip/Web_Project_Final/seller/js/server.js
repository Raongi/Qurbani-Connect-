const express = require('express');
const bcrypt = require('bcrypt');
const Seller = require('../models/Seller'); // Ensure correct path to your Seller model
const router = express.Router();

router.post('/api/auth/register', async (req, res) => {
  try {
    // Get data from the request body
    const { farmerName, email, password, phone, address, city, googleMapLink } = req.body;

    // Validate required fields
    if (!farmerName || !email || !password) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    // Check if the seller already exists by email
    const existingSeller = await Seller.findOne({ email: email });
    if (existingSeller) {
      return res.status(400).json({ message: 'Seller already exists with this email' });
    }

    // Hash the password using bcrypt
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create a new seller document with all fields
    const seller = new Seller({
      farmerName,
      email,
      password: hashedPassword,
      phone,
      address,
      city,
      googleMapLink,
      createdAt: new Date()
    });

    // Save the seller to the MongoDB database
    await seller.save();

    // Return success response
    res.status(201).json({ message: 'Registration successful', sellerId: seller._id });

  } catch (error) {
    console.error('Error registering seller:', error);
    res.status(500).json({ message: 'Registration failed', error: error.message });
  }
});

module.exports = router;
