// API base URL - change this to your C# backend URL
// Change to your actual backend port
const API_BASE_URL = 'http://localhost:5000/api/seller'; // Adjust to your actual backend port// Use the port from your backend output

// Check if user is logged in
function checkAuth() {
    const token = localStorage.getItem('sellerToken');
    if (!token && !window.location.href.includes('login.html') && !window.location.href.includes('register.html')) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
    
}

// Login function
async function login(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password }) // Send email and password to backend
        });

        const data = await response.json();

        // Check if login is successful
        if (response.ok) {
            // Store the JWT token in localStorage
            localStorage.removeItem('token');
            localStorage.setItem('sellerToken', data.token);

            // Redirect to the dashboard
            window.location.href = 'dashboard.html';
        } else {
            // If not successful, show error message
            const alertElement = document.getElementById('loginAlert');
            alertElement.textContent = data.message || 'Login failed';
            alertElement.classList.remove('d-none');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('An error occurred during login');
    }
}


// Login form handler
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        const result = await login(email, password);
    });
}


async function register(userData) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            const alertElement = document.getElementById('registerAlert');
            alertElement.textContent = "✅ Registration successful! Please login.";
            alertElement.classList.remove('d-none');
            alertElement.classList.remove('alert-danger');
            alertElement.classList.add('alert-success');

            setTimeout(() => {
                window.location.href = 'login.html'; // Auto redirect after 1.5 seconds
            }, 1500);
        } else {
            const alertElement = document.getElementById('registerAlert');
            alertElement.textContent = "❌ " + data.message;
            alertElement.classList.remove('d-none');
            alertElement.classList.remove('alert-success');
            alertElement.classList.add('alert-danger');
        }
    } catch (error) {
        console.error('Registration error:', error);
        const alertElement = document.getElementById('registerAlert');
        alertElement.textContent = "❌ An error occurred during registration.";
        alertElement.classList.remove('d-none');
        alertElement.classList.add('alert-danger');
    }
}




// Logout function
function logout() {
    localStorage.removeItem('sellerToken');
    localStorage.removeItem('user');
    // clear legacy key too
    localStorage.removeItem('token');
    window.location.href = 'login.html';
}

// Get current user
function getCurrentUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

// Initialize auth on page load
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    if (checkAuth()) {
        const user = getCurrentUser();
        if (user) {
            // Update UI with user data
            const userNameElements = document.querySelectorAll('#sellerName, #userName');
            userNameElements.forEach(element => {
                if (element) {
                    element.textContent = user.FarmerName || user.name || 'Farmer';
                }
            });
        }
    }
    
    // Login form handler
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            const result = await login(email, password);
            
            if (result.success) {
                window.location.href = 'dashboard.html';
            } else {
                const alertElement = document.getElementById('loginAlert');
                alertElement.textContent = result.message;
                alertElement.classList.remove('d-none');
            }
        });
    }
    
    // Register form handler
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (password !== confirmPassword) {
                const alertElement = document.getElementById('registerAlert');
                alertElement.textContent = 'Passwords do not match';
                alertElement.classList.remove('d-none');
                return;
            }
            
            const userData = {
                FarmerName: document.getElementById('farmerName').value,
                Email: document.getElementById('email').value,
                Password: password,
                Phone: document.getElementById('phone').value,
                Address: document.getElementById('address').value,
                City: document.getElementById('city').value,
                GoogleMapLink: document.getElementById('googleMapLink').value
            };
            
            const result = await register(userData);
            
            if (result.success) {
                window.location.href = 'login.html';
            } else {
                const alertElement = document.getElementById('registerAlert');
                alertElement.textContent = result.message;
                alertElement.classList.remove('d-none');
            }
        });
    }
    
    // Logout button handlers
    const logoutBtns = document.querySelectorAll('#logoutBtn, #logoutDropdown');
    logoutBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    });
});