// This file configures Live Server to properly serve your static files
module.exports = {
    port: 5500,
    host: "localhost",
    root: "/seller", // Set root to your pages folder
    open: true,
    cors: true,
    headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    }
};