// API base URL - change this to your C# backend URL
// Change to your actual backend port
const API_BASE_URL = 'http://localhost:5000/api/seller'; // Use the port from your backend output
// Get all animals
async function getAllAnimals() {
    try {
        const response = await fetch('http://localhost:5000/api/animals');
        const animals = await response.json();

        const animalsGrid = document.getElementById('animalsGrid');
        animalsGrid.innerHTML = '';

        animals.forEach(animal => {
            const animalCard = `
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="${animal.imageUrl}" class="card-img-top" alt="${animal.type}">
                        <div class="card-body">
                            <h5 class="card-title">${animal.type} - ${animal.breed}</h5>
                            <p class="card-text">Age: ${animal.age} months</p>
                            <p class="card-text">Price: $${animal.price}</p>
                            <p class="card-text">Status: ${animal.stockStatus}</p>
                        </div>
                    </div>
                </div>
            `;
            animalsGrid.innerHTML += animalCard;
        });
    } catch (error) {
        console.error('Error fetching animals:', error);
    }
}

// Call the function to load animals on page load
getAllAnimals();

// Add new animal
async function addAnimal(animalData) {
    const token = localStorage.getItem('token');
    
    try {
        const response = await fetch(`${API_BASE_URL}/animals`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(animalData)
        });
        
        if (response.ok) {
            const data = await response.json();
            return { success: true, animal: data };
        } else {
            const errorData = await response.json();
            return { success: false, message: errorData.message || 'Failed to add animal' };
        }
    } catch (error) {
        console.error('Error adding animal:', error);
        return { success: false, message: 'An error occurred while adding the animal' };
    }
}

// Update animal
async function updateAnimal(id, animalData) {
    const token = localStorage.getItem('token');
    
    try {
        const response = await fetch(`${API_BASE_URL}/animals/${id}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(animalData)
        });
        
        if (response.ok) {
            const data = await response.json();
            return { success: true, animal: data };
        } else {
            const errorData = await response.json();
            return { success: false, message: errorData.message || 'Failed to update animal' };
        }
    } catch (error) {
        console.error('Error updating animal:', error);
        return { success: false, message: 'An error occurred while updating the animal' };
    }
}

// Delete animal
async function deleteAnimal(id) {
    const token = localStorage.getItem('token');
    
    try {
        const response = await fetch(`${API_BASE_URL}/animals/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            return { success: true };
        } else {
            const errorData = await response.json();
            return { success: false, message: errorData.message || 'Failed to delete animal' };
        }
    } catch (error) {
        console.error('Error deleting animal:', error);
        return { success: false, message: 'An error occurred while deleting the animal' };
    }
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Render animals grid
function renderAnimalsGrid(animals) {
    const animalsGrid = document.getElementById('animalsGrid');
    
    if (animals && animals.length > 0) {
        animalsGrid.innerHTML = animals.map(animal => `
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="${animal.imageUrl || 'https://picsum.photos/seed/' + animal.id + '/400/300.jpg'}" class="card-img-top" alt="${animal.type}">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title">${animal.breed}</h5>
                            <span class="badge badge-${animal.status === 'available' ? 'approved' : animal.status === 'sold' ? 'completed' : 'pending'}">
                                ${animal.status}
                            </span>
                        </div>
                        <p class="card-text">${animal.type}</p>
                        <ul class="list-unstyled mb-3">
                            <li><strong>Age:</strong> ${animal.age} months</li>
                            <li><strong>Weight:</strong> ${animal.weight} kg</li>
                            <li><strong>Gender:</strong> ${animal.gender}</li>
                            <li><strong>Price:</strong> $${animal.price}</li>
                        </ul>
                        <div class="mt-auto d-flex justify-content-between">
                            <button class="btn btn-sm btn-edit" onclick="editAnimal(${animal.id})">Edit</button>
                            <button class="btn btn-sm btn-delete" onclick="confirmDeleteAnimal(${animal.id})">Delete</button>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    } else {
        animalsGrid.innerHTML = '<div class="col-12 text-center py-5">No animals found. Add your first animal to get started.</div>';
    }
}

// Edit animal
function editAnimal(id) {
    // Fetch animal details and populate the edit form
    fetch(`${API_BASE_URL}/animals/${id}`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(animal => {
        // Populate edit form
        document.getElementById('editAnimalId').value = animal.id;
        document.getElementById('editAnimalType').value = animal.type;
        document.getElementById('editAnimalBreed').value = animal.breed;
        document.getElementById('editAnimalAge').value = animal.age;
        document.getElementById('editAnimalWeight').value = animal.weight;
        document.getElementById('editAnimalPrice').value = animal.price;
        document.getElementById('editAnimalGender').value = animal.gender;
        document.getElementById('editAnimalStatus').value = animal.status;
        document.getElementById('editAnimalDescription').value = animal.description || '';
        
        // Show edit modal
        const editModal = new bootstrap.Modal(document.getElementById('editAnimalModal'));
        editModal.show();
    })
    .catch(error => {
        console.error('Error fetching animal details:', error);
        alert('Failed to fetch animal details');
    });
}

// Confirm delete animal
function confirmDeleteAnimal(id) {
    if (confirm('Are you sure you want to delete this animal?')) {
        deleteAnimal(id)
            .then(result => {
                if (result.success) {
                    alert('Animal deleted successfully');
                    loadAnimals(); // Reload the animals grid
                } else {
                    alert(result.message || 'Failed to delete animal');
                }
            });
    }
}

// Load animals
function loadAnimals() {
    getAnimals()
        .then(animals => {
            renderAnimalsGrid(animals);
        });
}

// Initialize animals page
document.addEventListener('DOMContentLoaded', function() {
    // Load animals on page load
    loadAnimals();
    
    // Handle add animal form submission
    document.getElementById('saveAnimalBtn').addEventListener('click', function() {
        const animalData = {
            type: document.getElementById('animalType').value,
            breed: document.getElementById('animalBreed').value,
            age: parseInt(document.getElementById('animalAge').value),
            weight: parseFloat(document.getElementById('animalWeight').value),
            price: parseFloat(document.getElementById('animalPrice').value),
            gender: document.getElementById('animalGender').value,
            description: document.getElementById('animalDescription').value,
            status: 'available'
        };
        
        addAnimal(animalData)
            .then(result => {
                if (result.success) {
                    alert('Animal added successfully');
                    bootstrap.Modal.getInstance(document.getElementById('addAnimalModal')).hide();
                    document.getElementById('addAnimalForm').reset();
                    loadAnimals(); // Reload the animals grid
                } else {
                    alert(result.message || 'Failed to add animal');
                }
            });
    });
    
    // Handle update animal form submission
    document.getElementById('updateAnimalBtn').addEventListener('click', function() {
        const id = document.getElementById('editAnimalId').value;
        const animalData = {
            type: document.getElementById('editAnimalType').value,
            breed: document.getElementById('editAnimalBreed').value,
            age: parseInt(document.getElementById('editAnimalAge').value),
            weight: parseFloat(document.getElementById('editAnimalWeight').value),
            price: parseFloat(document.getElementById('editAnimalPrice').value),
            gender: document.getElementById('editAnimalGender').value,
            description: document.getElementById('editAnimalDescription').value,
            status: document.getElementById('editAnimalStatus').value
        };
        
        updateAnimal(id, animalData)
            .then(result => {
                if (result.success) {
                    alert('Animal updated successfully');
                    bootstrap.Modal.getInstance(document.getElementById('editAnimalModal')).hide();
                    loadAnimals(); // Reload the animals grid
                } else {
                    alert(result.message || 'Failed to update animal');
                }
            });
    });
    
    // Handle search and filter
    document.getElementById('searchInput').addEventListener('input', function() {
        filterAnimals();
    });
    
    document.getElementById('filterType').addEventListener('change', function() {
        filterAnimals();
    });
    
    document.getElementById('filterStatus').addEventListener('change', function() {
        filterAnimals();
    });
});

// Filter animals based on search and filter criteria
function filterAnimals() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const typeFilter = document.getElementById('filterType').value;
    const statusFilter = document.getElementById('filterStatus').value;
    
    getAnimals()
        .then(animals => {
            let filteredAnimals = animals;
            
            // Apply search filter
            if (searchTerm) {
                filteredAnimals = filteredAnimals.filter(animal => 
                    animal.breed.toLowerCase().includes(searchTerm) ||
                    animal.type.toLowerCase().includes(searchTerm) ||
                    animal.description.toLowerCase().includes(searchTerm)
                );
            }
            
            // Apply type filter
            if (typeFilter) {
                filteredAnimals = filteredAnimals.filter(animal => animal.type === typeFilter);
            }
            
            // Apply status filter
            if (statusFilter) {
                filteredAnimals = filteredAnimals.filter(animal => animal.status === statusFilter);
            }
            
            renderAnimalsGrid(filteredAnimals);
        });
}