// API base URL - change this to your C# backend URL
// Change to your actual backend port
const API_BASE_URL = 'http://localhost:5000/api/seller'; // Use the port from your backend output

// Get dashboard statistics
async function getDashboardStats() {
    const token = localStorage.getItem('sellerToken');
    
    try {
        const response = await fetch(`${API_BASE_URL}/dashboard/stats`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            return data;
        } else {
            console.error('Failed to fetch dashboard stats');
            return null;
        }
    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        return null;
    }
}

// Get recent orders
async function getRecentOrders() {
    const token = localStorage.getItem('sellerToken');
    
    try {
        const response = await fetch(`${API_BASE_URL}/orders/recent`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (response.ok) {
            const data = await response.json();
            return data;
        } else {
            console.error('Failed to fetch recent orders');
            return [];
        }
    } catch (error) {
        console.error('Error fetching recent orders:', error);
        return [];
    }
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', async function() {
    // Get dashboard statistics
    const stats = await getDashboardStats();
    if (stats) {
        document.getElementById('totalAnimals').textContent = stats.totalAnimals || 0;
        document.getElementById('activeListings').textContent = stats.activeListings || 0;
        document.getElementById('pendingOrders').textContent = stats.pendingOrders || 0;
        document.getElementById('completedOrders').textContent = stats.completedOrders || 0;
    }
    
    // Get recent orders
    const orders = await getRecentOrders();
    const ordersTable = document.getElementById('recentOrdersTable');
    
    if (orders && orders.length > 0) {
        ordersTable.innerHTML = orders.map(order => `
            <tr>
                <td>${order.id}</td>
                <td>${order.animalType} - ${order.breed}</td>
                <td>${order.buyerName}</td>
                <td>${formatDate(order.orderDate)}</td>
                <td>$${order.amount.toFixed(2)}</td>
                <td>
                    <span class="badge badge-${order.status === 'completed' ? 'completed' : order.status === 'pending' ? 'pending' : 'approved'}">
                        ${order.status}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-edit">View</button>
                </td>
            </tr>
        `).join('');
    } else {
        ordersTable.innerHTML = '<tr><td colspan="7" class="text-center">No recent orders</td></tr>';
    }
});