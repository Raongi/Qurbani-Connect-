// Dashboard JavaScript

async function loadAdminName() {
    try {
        const adminName = localStorage.getItem('adminName');
        if (adminName) {
            document.getElementById('adminName').textContent = adminName;
        }
    } catch (error) {
        console.error('Error loading admin name:', error);
    }
}

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    loadAdminName();
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutDropdown = document.getElementById('logoutDropdown');
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
    
    if (logoutDropdown) {
        logoutDropdown.addEventListener('click', function(e) {
            e.preventDefault();
            logout();
        });
    }
});

function logout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminId');
    localStorage.removeItem('adminName');
    window.location.href = 'login.html';
}
