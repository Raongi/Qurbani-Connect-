// API base URL
const API_BASE_URL = 'http://localhost:5000/api/admin';

// Check if user is logged in
function checkAuth() {
    const token = localStorage.getItem('adminToken');

    const clearAuth = () => {
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminId');
        localStorage.removeItem('adminName');
    };

    const decodeJwtPayload = (t) => {
        const part = (t || '').split('.')[1];
        if (!part) return null;
        const base64 = part.replace(/-/g, '+').replace(/_/g, '/');
        const padded = base64 + '==='.slice((base64.length + 3) % 4);
        return JSON.parse(atob(padded));
    };

    const isValidAdminToken = (t) => {
        if (!t) return false;
        try {
            const payload = decodeJwtPayload(t);
            if (!payload) return false;
            if (payload.role !== 'admin') return false;
            const expMs = (payload.exp || 0) * 1000;
            if (expMs && Date.now() >= expMs) return false;
            return true;
        } catch {
            return false;
        }
    };

    if (token && !isValidAdminToken(token)) {
        clearAuth();
    }

    const validToken = isValidAdminToken(localStorage.getItem('adminToken'));
    if (
        !validToken &&
        !window.location.href.includes('login.html') &&
        !window.location.href.includes('register.html') &&
        !window.location.href.includes('index.html')
    ) {
        window.location.href = 'login.html';
        return false;
    }
    return true;
}

// Login function
async function login(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (response.ok) {
            localStorage.setItem('adminToken', data.token);
            localStorage.setItem('adminId', data.adminId);
            // backend returns: fullName (NOT adminName)
            localStorage.setItem('adminName', data.fullName || 'Admin');

            window.location.href = 'dashboard.html';
        } else {
            const alertElement = document.getElementById('loginAlert');
            if (alertElement) {
                alertElement.textContent = data.message || 'Login failed';
                alertElement.classList.remove('d-none');
            }
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('An error occurred during login');
    }
}

// Register function
async function register(userData) {
    try {
        const response = await fetch(`${API_BASE_URL}/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(userData)
        });

        const data = await response.json();

        if (response.ok) {
            const alertElement = document.getElementById('registerAlert');
            if (alertElement) {
                alertElement.textContent = "✅ Registration successful! Please login.";
                alertElement.classList.remove('d-none');
                alertElement.classList.remove('alert-danger');
                alertElement.classList.add('alert-success');
            }

            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
        } else {
            const alertElement = document.getElementById('registerAlert');
            if (alertElement) {
                alertElement.textContent = "❌ " + (data.message || "Registration failed");
                alertElement.classList.remove('d-none');
                alertElement.classList.remove('alert-success');
                alertElement.classList.add('alert-danger');
            }
        }
    } catch (error) {
        console.error('Registration error:', error);
        const alertElement = document.getElementById('registerAlert');
        if (alertElement) {
            alertElement.textContent = "❌ An error occurred during registration.";
            alertElement.classList.remove('d-none');
            alertElement.classList.add('alert-danger');
        }
    }
}

// Logout function
function logout() {
    localStorage.removeItem('adminToken');
    localStorage.removeItem('adminId');
    localStorage.removeItem('adminName');
    window.location.href = 'login.html';
}

// Setup logout buttons
function setupLogoutButtons() {
    const logoutBtn = document.getElementById('logoutBtn');
    const logoutDropdown = document.getElementById('logoutDropdown');

    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }

    if (logoutDropdown) {
        logoutDropdown.addEventListener('click', (e) => {
            e.preventDefault();
            logout();
        });
    }
}

// Run on page load
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupLogoutButtons();
});