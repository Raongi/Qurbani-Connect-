// Transporters Management JavaScript

async function loadTransporters() {
    try {
        const token = localStorage.getItem('adminToken');
        console.log('Token:', token ? '✓ Present' : '✗ Missing');

        const response = await fetch(`${API_BASE_URL}/api/admin/transport`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch transporters`);
        }

        const data = await response.json();
        console.log('Transporters response:', data);
        displayTransporters(data);
    } catch (error) {
        console.error('Error loading transporters:', error);
        document.getElementById('transportersTableBody').innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-danger">Error: ${error.message}</td>
            </tr>
        `;
    }
}

function displayTransporters(response) {
    const tbody = document.getElementById('transportersTableBody');

    const transporters = Array.isArray(response) ? response : (response.transporters || []);

    if (!transporters || transporters.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted">No transporters found</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = transporters.map((t, index) => `
        <tr>
            <td>${t.id || t.Id || index + 1}</td>
            <td>${t.fullName || t.FullName || t.transporterName || t.TransporterName || t.name || t.Name || 'N/A'}</td>
            <td>${t.email || t.Email || 'N/A'}</td>
            <td>${t.phone || t.Phone || 'N/A'}</td>
            <td>${t.vehicleType || t.VehicleType || 'N/A'}</td>
            <td>${t.licenseNumber || t.LicenseNumber || t.licensePlate || t.LicensePlate || 'N/A'}</td>
            <td><span class="badge-approved">Active</span></td>
            <td>${t.createdAt || t.CreatedAt ? new Date(t.createdAt || t.CreatedAt).toLocaleDateString() : 'N/A'}</td>
            <td>
                <button class="btn btn-sm btn-view" onclick="viewTransporter('${t.id || t.Id || ''}')">View</button>
                <button class="btn btn-sm btn-danger" onclick="deleteTransporter('${t.id || t.Id || ''}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

function viewTransporter(transporterId) {
    alert(`View transporter: ${transporterId}`);
}

function deleteTransporter(transporterId) {
    if (confirm('Are you sure you want to delete this transporter?')) {
        alert(`Delete transporter: ${transporterId}`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadTransporters();

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#transportersTableBody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});