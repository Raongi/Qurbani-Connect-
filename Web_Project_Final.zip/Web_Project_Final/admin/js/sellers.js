// Sellers Management JavaScript

async function loadSellers() {
    try {
        const token = localStorage.getItem('adminToken');
        console.log('Token:', token ? '✓ Present' : '✗ Missing');

        const response = await fetch(`${API_BASE_URL}/api/admin/seller`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch sellers`);
        }

        const data = await response.json();
        console.log('Sellers response:', data);
        displaySellers(data);
    } catch (error) {
        console.error('Error loading sellers:', error);
        document.getElementById('sellersTableBody').innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-danger">Error: ${error.message}</td>
            </tr>
        `;
    }
}

function displaySellers(response) {
    const tbody = document.getElementById('sellersTableBody');

    const sellers = Array.isArray(response) ? response : (response.sellers || []);

    if (!sellers || sellers.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted">No sellers found</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = sellers.map((seller, index) => `
        <tr>
            <td>${seller.id || seller.Id || index + 1}</td>
            <td>${seller.fullName || seller.FullName || seller.name || seller.Name || seller.farmerName || 'N/A'}</td>
            <td>${seller.email || seller.Email || 'N/A'}</td>
            <td>${seller.phone || seller.Phone || 'N/A'}</td>
            <td>${seller.location || seller.Location || seller.city || seller.City || 'N/A'}</td>
            <td>${seller.animalsCount || seller.AnimalsCount || 0}</td>
            <td><span class="badge-approved">Active</span></td>
            <td>${seller.createdAt || seller.CreatedAt ? new Date(seller.createdAt || seller.CreatedAt).toLocaleDateString() : 'N/A'}</td>
            <td>
                <button class="btn btn-sm btn-view" onclick="viewSeller('${seller.id || seller.Id || ''}')">View</button>
                <button class="btn btn-sm btn-danger" onclick="deleteSeller('${seller.id || seller.Id || ''}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

function viewSeller(sellerId) {
    alert(`View seller: ${sellerId}`);
}

function deleteSeller(sellerId) {
    if (confirm('Are you sure you want to delete this seller?')) {
        alert(`Delete seller: ${sellerId}`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadSellers();

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#sellersTableBody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});