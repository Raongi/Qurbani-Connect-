// Admin Profile JavaScript

async function loadAdminProfile() {
    try {
        const token = localStorage.getItem('token');
        
        const response = await fetch(`${API_BASE_URL}/profile`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) {
            throw new Error('Failed to fetch profile');
        }

        const admin = await response.json();
        displayProfile(admin);
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

function displayProfile(admin) {
    // Update header
    document.getElementById('adminFullName').textContent = admin.fullName || 'Admin';
    document.getElementById('adminEmail').textContent = admin.email || 'N/A';
    
    // Update form fields
    document.getElementById('fullName').value = admin.fullName || '';
    document.getElementById('email').value = admin.email || '';
    document.getElementById('phone').value = admin.phone || '';
    document.getElementById('location').value = admin.location || '';
    document.getElementById('bio').value = admin.bio || '';
}

// Handle profile form submission
document.addEventListener('DOMContentLoaded', () => {
    loadAdminProfile();
    
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const token = localStorage.getItem('token');
            const updateData = {
                fullName: document.getElementById('fullName').value,
                phone: document.getElementById('phone').value,
                location: document.getElementById('location').value,
                bio: document.getElementById('bio').value
            };

            try {
                const response = await fetch(`${API_BASE_URL}/profile/update`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(updateData)
                });

                if (response.ok) {
                    alert('Profile updated successfully!');
                    loadAdminProfile();
                } else {
                    alert('Failed to update profile');
                }
            } catch (error) {
                console.error('Error updating profile:', error);
                alert('An error occurred while updating profile');
            }
        });
    }

    // Handle password form submission
    const passwordForm = document.getElementById('passwordForm');
    if (passwordForm) {
        passwordForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (newPassword !== confirmPassword) {
                alert('New passwords do not match!');
                return;
            }

            const token = localStorage.getItem('token');
            
            try {
                const response = await fetch(`${API_BASE_URL}/change-password`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        currentPassword,
                        newPassword
                    })
                });

                if (response.ok) {
                    alert('Password changed successfully!');
                    passwordForm.reset();
                } else {
                    alert('Failed to change password');
                }
            } catch (error) {
                console.error('Error changing password:', error);
                alert('An error occurred while changing password');
            }
        });
    }
});
