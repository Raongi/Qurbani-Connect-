// Users Management JavaScript

async function loadUsers() {
    try {
        const token = localStorage.getItem('adminToken');
        console.log('Token stored:', token ? token.substring(0, 20) + '...' : 'Missing');
        
        if (!token) {
            throw new Error('No authentication token found. Please login again.');
        }
        
        const response = await fetch(`${API_BASE_URL}/users`, {
            method: 'GET',
            headers: { 
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        console.log('Response status:', response.status);
        console.log('Response headers:', response.headers);

        if (!response.ok) {
            const errorText = await response.text();
            console.error('Response error body:', errorText);
            throw new Error(`HTTP ${response.status}: Failed to fetch users`);
        }

        const data = await response.json();
        console.log('Users response:', data);
        displayUsers(data);
    } catch (error) {
        console.error('Error loading users:', error);
        document.getElementById('usersTableBody').innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-danger">Error: ${error.message}</td>
            </tr>
        `;
    }
}

function displayUsers(response) {
    const tbody = document.getElementById('usersTableBody');
    
    // Handle both direct array and nested response
    const users = Array.isArray(response) ? response : (response.users || []);
    
    if (!users || users.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-muted">No users found</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = users.map((user, index) => `
        <tr>
            <td>${user.id || index + 1}</td>
            <td>${user.fullName || user.name || 'N/A'}</td>
            <td>${user.email || 'N/A'}</td>
            <td>${user.phone || 'N/A'}</td>
            <td>${user.location || 'N/A'}</td>
            <td><span class="badge-approved">Active</span></td>
            <td>${user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}</td>
            <td>
                <button class="btn btn-sm btn-view" onclick="viewUser('${user.id}')">View</button>
                <button class="btn btn-sm btn-danger" onclick="deleteUser('${user.id}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

function viewUser(userId) {
    alert(`View user: ${userId}`);
}

function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        alert(`Delete user: ${userId}`);
    }
}

// Search functionality
document.addEventListener('DOMContentLoaded', () => {
    loadUsers();
    
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#usersTableBody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});
