// Butchers Management JavaScript

async function loadButchers() {
    try {
        const token = localStorage.getItem('adminToken');
        console.log('Token:', token ? '✓ Present' : '✗ Missing');

        const response = await fetch(`${API_BASE_URL}/api/admin/butchers`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: Failed to fetch butchers`);
        }

        const data = await response.json();
        console.log('Butchers response:', data);
        displayButchers(data);
    } catch (error) {
        console.error('Error loading butchers:', error);
        document.getElementById('butchersTableBody').innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-danger">Error: ${error.message}</td>
            </tr>
        `;
    }
}

function displayButchers(response) {
    const tbody = document.getElementById('butchersTableBody');

    const butchers = Array.isArray(response) ? response : (response.butchers || []);

    if (!butchers || butchers.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center text-muted">No butchers found</td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = butchers.map((butcher, index) => `
        <tr>
            <td>${butcher.id || butcher.Id || index + 1}</td>
            <td>${butcher.fullName || butcher.FullName || butcher.name || butcher.Name || 'N/A'}</td>
            <td>${butcher.email || butcher.Email || 'N/A'}</td>
            <td>${butcher.phone || butcher.Phone || 'N/A'}</td>
            <td>${butcher.location || butcher.Location || butcher.address || butcher.Address || 'N/A'}</td>
            <td>${butcher.shopName || butcher.ShopName || 'N/A'}</td>
            <td><span class="badge-approved">Active</span></td>
            <td>${butcher.createdAt || butcher.CreatedAt ? new Date(butcher.createdAt || butcher.CreatedAt).toLocaleDateString() : 'N/A'}</td>
            <td>
                <button class="btn btn-sm btn-view" onclick="viewButcher('${butcher.id || butcher.Id || ''}')">View</button>
                <button class="btn btn-sm btn-danger" onclick="deleteButcher('${butcher.id || butcher.Id || ''}')">Delete</button>
            </td>
        </tr>
    `).join('');
}

function viewButcher(butcherId) {
    alert(`View butcher: ${butcherId}`);
}

function deleteButcher(butcherId) {
    if (confirm('Are you sure you want to delete this butcher?')) {
        alert(`Delete butcher: ${butcherId}`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadButchers();

    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#butchersTableBody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});